import javax.swing.JFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.LayoutStyle.ComponentPlacement;

public class AdminSection extends JFrame
{
	public AdminSection() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(this);
		setSize(800,800);
		
		JLabel lblAdminSection = new JLabel("ADMIN SECTION");
		
		JButton btnAddNewBook = new JButton("Add New Book");
		btnAddNewBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AddNewBook obj = new AddNewBook();
				obj.setVisible(true);
			}
		});
	
		
		JButton btnSearchupdatedeleteBook = new JButton("Search/Update/Delete Book");
		btnSearchupdatedeleteBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				SearchUpdateDelete obj = new SearchUpdateDelete();
				obj.setVisible(true);
			}
		});
		
		JButton btnViewsearchBook = new JButton("View/Search Book");
		btnViewsearchBook.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				SearchBy obj = new SearchBy();
				obj.setVisible(true);
			}
		});
		
		JButton btnAddUser = new JButton("Add User");
		btnAddUser.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AddUser obj = new AddUser();
				obj.setVisible(true);
			}
		});
		
		JButton btnSearchupdatedeleteUser = new JButton("Search/Update/Delete User");
		btnSearchupdatedeleteUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				SearchUpdateDeleteUser obj = new SearchUpdateDeleteUser();
				obj.setVisible(true);
			}
		});
		
		JButton btnSubmitBook = new JButton("Submit Book");
		btnSubmitBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				IssueBookForm1 obj = new IssueBookForm1();
				obj.setVisible(true);
			}
		});
		
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(336)
							.addComponent(lblAdminSection))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(109)
							.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING, false)
								.addComponent(btnSubmitBook, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(btnAddUser, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(btnAddNewBook, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE))
							.addGap(147)
							.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
								.addComponent(btnSearchupdatedeleteBook)
								.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
									.addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup()
										.addComponent(btnSearchupdatedeleteUser, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addPreferredGap(ComponentPlacement.RELATED))
									.addComponent(btnViewsearchBook, Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 170, GroupLayout.PREFERRED_SIZE)))
							.addGap(56)))
					.addContainerGap(124, GroupLayout.PREFERRED_SIZE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(26)
					.addComponent(lblAdminSection)
					.addGap(71)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnAddNewBook, GroupLayout.PREFERRED_SIZE, 105, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnSearchupdatedeleteBook, GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE))
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(63)
							.addComponent(btnAddUser, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(73)
							.addComponent(btnViewsearchBook, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
					.addGap(57)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnSubmitBook, GroupLayout.PREFERRED_SIZE, 92, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnSearchupdatedeleteUser, GroupLayout.PREFERRED_SIZE, 94, GroupLayout.PREFERRED_SIZE))
					.addContainerGap())
		);
		getContentPane().setLayout(groupLayout);
	}

  public static void main(String[] args)
  {
	AdminSection as = new AdminSection();
	as.setVisible(true);
}
}