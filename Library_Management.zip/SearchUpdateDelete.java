import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import com.mysql.jdbc.ResultSet;

import javax.swing.JComboBox;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.JButton;

public class SearchUpdateDelete extends JFrame implements ActionListener
{
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JLabel lblNewLabel;
	private JLabel lblBookid;
	private JLabel lblTitle;
	private JLabel lblAuthor;
	private JLabel lblPublication;
	private JLabel lblCategory;
	private JLabel lblSubject;
	private JLabel lblIsbn;
	private JLabel lblEdition;
	private JLabel lblPrice;
	private JLabel lblQuantity;
	private JComboBox comboBox;
	private JComboBox comboBox_1;
	private JComboBox comboBox_2;
	private JComboBox comboBox_3;
	private JButton btnReset;
	private JButton btnSearch;
	private JButton btnUpdate;
	private JButton btnDelete;
	private JTextField textField_5;
	public void reset()
	{
		 textField.setText(null);
	      textField_1.setText(null);
	      textField_2.setText(null);
	      textField_3.setText(null);
	      textField_4.setText(null);
	      textField_5.setText(null);
	      comboBox.setSelectedIndex(0);
	      comboBox_1.setSelectedIndex(0);
	      comboBox_2.setSelectedIndex(0);
	      comboBox_3.setSelectedIndex(0);
	}
	public SearchUpdateDelete() {
		getContentPane().setLayout(null);
		
		lblNewLabel = new JLabel("New Label");
		lblNewLabel.setBounds(264, 13, 56, 16);
		getContentPane().add(lblNewLabel);
		
		lblBookid = new JLabel("Book_id");
		lblBookid.setBounds(51, 60, 56, 16);
		getContentPane().add(lblBookid);
		
		lblTitle = new JLabel("Title");
		lblTitle.setBounds(51, 107, 56, 16);
		getContentPane().add(lblTitle);
		
		lblAuthor = new JLabel("Author");
		lblAuthor.setBounds(51, 157, 56, 16);
		getContentPane().add(lblAuthor);
		
		lblPublication = new JLabel("Publication");
		lblPublication.setBounds(51, 207, 56, 16);
		getContentPane().add(lblPublication);
		
		lblCategory = new JLabel("Category");
		lblCategory.setBounds(51, 255, 56, 16);
		getContentPane().add(lblCategory);
		
		lblSubject = new JLabel("Subject");
		lblSubject.setBounds(51, 305, 56, 16);
		getContentPane().add(lblSubject);
		
		lblIsbn = new JLabel("Isbn");
		lblIsbn.setBounds(51, 356, 56, 16);
		getContentPane().add(lblIsbn);
		
		lblEdition = new JLabel("Edition");
		lblEdition.setBounds(51, 394, 56, 16);
		getContentPane().add(lblEdition);
		
		lblPrice = new JLabel("Price");
		lblPrice.setBounds(51, 438, 56, 16);
		getContentPane().add(lblPrice);
		
		lblQuantity = new JLabel("Quantity");
		lblQuantity.setBounds(51, 438, 56, 16);
		getContentPane().add(lblQuantity);
		
		textField = new JTextField();
		textField.setBounds(197, 54, 324, 29);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(197, 101, 324, 29);
		getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		comboBox = new JComboBox(DBInfo.getAuthor());
		comboBox.setBounds(197, 151, 324, 29);
		getContentPane().add(comboBox);
		comboBox.insertItemAt("Select", 0);
		comboBox.setSelectedIndex(0);
		
		comboBox_1 = new JComboBox(DBInfo.getPublisher());
		comboBox_1.setBounds(197, 201, 324, 29);
		getContentPane().add(comboBox_1);
		comboBox_1.insertItemAt("Select", 0);
		comboBox_1.setSelectedIndex(0);
		
		comboBox_2 = new JComboBox(DBInfo.getCategory());
		comboBox_2.setBounds(197, 249, 324, 29);
		getContentPane().add(comboBox_2);
		comboBox_2.insertItemAt("Select", 0);
		comboBox_2.setSelectedIndex(0);
		
		comboBox_3 = new JComboBox(DBInfo.getSubject());
		comboBox_3.setBounds(197, 299, 324, 29);
		getContentPane().add(comboBox_3);
		comboBox_3.insertItemAt("Select", 0);
		comboBox_3.setSelectedIndex(0);
		
		textField_2 = new JTextField();
		textField_2.setBounds(197, 346, 324, 29);
		getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(197, 388, 324, 29);
		getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(197, 432, 324, 29);
		getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		btnReset = new JButton("RESET");
		btnReset.setBounds(33, 551, 97, 36);
		getContentPane().add(btnReset);
		
		btnSearch = new JButton("SEARCH");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String id=textField.getText();
				int flag=0;
				String query = "select * from book where Book_id=?";
				try
				{
					PreparedStatement ps = DBInfo.con.prepareStatement(query);
					ps.setString(1, id);
					ResultSet res= (ResultSet) ps.executeQuery();
					while(res.next())
					{
						flag=1;
						String title=res.getString(2);
						String author=res.getString(3);
						String pub=res.getString(4);
						String cat=res.getString(5);
						String sub=res.getString(6);
						String isbn=res.getString(7);
						String edition=res.getString(8);
						String price=res.getString(9);
						String quantity=res.getString(10);
						textField_1.setText(title);
						comboBox.setSelectedItem(author);
						comboBox_1.setSelectedItem(pub);
						comboBox_2.setSelectedItem(cat);
						comboBox_3.setSelectedItem(sub);
						textField_2.setText(isbn);
						textField_3.setText(edition);
						textField_4.setText(price);
						textField_5.setText(quantity);
						break;
					}
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				if(flag==0)
				{
					JOptionPane.showMessageDialog(getParent(), "No Book Found!", "Error", JOptionPane.ERROR_MESSAGE);
				}
				
			}
		});
		btnSearch.setBounds(168, 551, 97, 36);
		getContentPane().add(btnSearch);
		
		btnUpdate = new JButton("UPDATE");
		btnUpdate.setBounds(307, 551, 97, 36);
		getContentPane().add(btnUpdate);
		
		btnUpdate.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				String id=textField.getText();
				  String title=textField_1.getText();
				  String author=(String)comboBox.getSelectedItem();
				  String pub=(String)comboBox_1.getSelectedItem();
				  String cat=(String)comboBox_2.getSelectedItem();
				  String sub=(String)comboBox_3.getSelectedItem();
				  String isbn=textField_2.getText();
				  String edition=textField_3.getText();
				  String price=textField_4.getText();
				  String quantity = textField_5.getText();
				  
				  if(id.length()==0 || title.length()==0 || author.equalsIgnoreCase("select") || pub.equalsIgnoreCase("select") || cat.equalsIgnoreCase("select") || sub.equalsIgnoreCase("select")|| isbn.length()==0 || edition.length()==0 || price.length()==0 || quantity.length()==0)
				  {
					  JOptionPane.showMessageDialog(SearchUpdateDelete.this, "Pls fill/select all the fields", "Error", JOptionPane.ERROR_MESSAGE);				  
				  }
				  else
				  {
					  
				
String query="update book set Book_id=?,Title=?,Author=?,Publisher=?,Category=?,Subject=?,Isbn=?,Edition=?,Price=?,quantity=? where Book_id=?";
				  int flag=0;
				  Connection con=DBInfo.con;
				  try
				  {
					 PreparedStatement ps=con.prepareStatement(query);
					 
					 ps.setString(1, id);
					 ps.setString(2, title);
					 ps.setString(3, author);
					 ps.setString(4, pub);
					 ps.setString(5, cat);
					 ps.setString(6, sub);
					 ps.setString(7, isbn);
					 ps.setString(8, edition);
					 ps.setString(9,price);
					 ps.setString(10, quantity);
					 ps.setString(11, id);
					
					 flag=ps.executeUpdate();
					 
				  }
				  catch(Exception e)
				  {
					  e.printStackTrace();
				  }
				  if(flag==1)
				  {
					  JOptionPane.showMessageDialog(SearchUpdateDelete.this, "Book updated!!", "Success", JOptionPane.INFORMATION_MESSAGE);
				      textField.setText(null);
				      textField_1.setText(null);
				      textField_2.setText(null);
				      textField_3.setText(null);
				      textField_4.setText(null);
				      textField_5.setText(null);
				   
				      comboBox.setSelectedIndex(0);
				      comboBox_1.setSelectedIndex(0);
				      comboBox_2.setSelectedIndex(0);
				      comboBox_3.setSelectedIndex(0);
				      
				      
				  }
				  else
				  {
					  JOptionPane.showMessageDialog(SearchUpdateDelete.this, "Book Not Updated", "Error", JOptionPane.ERROR_MESSAGE);
				  }
				  }
			}			  
		});
		
		btnDelete = new JButton("DELETE");
		btnDelete.setBounds(449, 551, 97, 36);
		getContentPane().add(btnDelete);
		
		textField_5 = new JTextField();
		textField_5.setBounds(197, 474, 324, 29);
		getContentPane().add(textField_5);
		textField_5.setColumns(10);
		
		JLabel lblQuantity = new JLabel("Quantity");
		lblQuantity.setBounds(51, 480, 56, 16);
		getContentPane().add(lblQuantity);
		
		btnDelete.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				String s = textField.getText();
				
				int flag = 0;
				
				try
				{
					Class.forName("com.mysql.jdbc.Driver");
	            	Connection con = DriverManager.getConnection("jdbc:mysql://localhost/lbmgmt","root","");
	        		System.out.println("connection is:"+con);
	        		PreparedStatement ps = con.prepareStatement("delete from book where Book_id=?");
	        		 ps.setString(1, s);
	        		 
	        		 flag = ps.executeUpdate();
	        		 
	        		 
	        		 if (flag != 0) 
	                 {
	                     JOptionPane.showMessageDialog(getParent(), "Data Deleted Successfully");
	                     reset();
	                 }
	        		 if(flag == 0)
	 				{
	 					JOptionPane.showMessageDialog(getParent(), "Record Not Deleted!!");
	 				}
	        		 
				}
				 catch (Exception ex) 
	            {
	                System.out.println(ex);
	            }	
				
				
			}
		});
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}