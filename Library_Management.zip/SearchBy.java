import javax.swing.JFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SearchBy extends JFrame{
	public SearchBy() {
		
		JLabel lblSearchBy = new JLabel("Search By");
		
		
		String values[] = {"Select","Author","Publisher","Category","Subject","All"};
		JComboBox comboBox = new JComboBox(values);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String value = (String) comboBox.getSelectedItem();
				if(value.equalsIgnoreCase("select"))
				{
					JOptionPane.showMessageDialog(getParent(), "Select a value", "ERROR", JOptionPane.ERROR_MESSAGE);
				}
				if(value.equalsIgnoreCase("all"))
				{
				JFrame frm=new JFrame();
				
				frm.setSize(900, 400);
				frm.setLocationRelativeTo(frm);
				frm.setDefaultCloseOperation(frm.DISPOSE_ON_CLOSE);
				
				DBInfo.getAllBooks();
				
				JTable t=new JTable(DBInfo.outer, DBInfo.header);
				JScrollPane pane=new JScrollPane(t);
				frm.add(pane);
				frm.setVisible(true);
				
				}
				else
				{
				  //String name=JOptionPane.showInputDialog("Enter "+value+" name");	
				  SearchValuesDialogBox obj=new SearchValuesDialogBox(value);
				  obj.setVisible(true);	
				}
			}
		});
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(76)
							.addComponent(lblSearchBy, GroupLayout.PREFERRED_SIZE, 74, GroupLayout.PREFERRED_SIZE)
							.addGap(107)
							.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, 160, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(138)
							.addComponent(btnSearch, GroupLayout.PREFERRED_SIZE, 146, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(75, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(100)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblSearchBy, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE)
						.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE))
					.addGap(36)
					.addComponent(btnSearch, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(101, Short.MAX_VALUE))
		);
		getContentPane().setLayout(groupLayout);
	}
	
}