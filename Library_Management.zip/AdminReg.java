import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.JPasswordField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.JButton;

public class AdminReg extends JFrame implements ActionListener 

{
	private JLabel lblName;
	private JLabel lblDob;
	private JLabel lblGender;
	private JLabel lblMobile;
	private JLabel lblEmail;
	private JLabel lblJoiningdate;
	private JLabel lblAddress;
	private JLabel lblPassword;
	
	private JComboBox comboBox_2;
	private JComboBox comboBox_3;
	private JComboBox comboBox_4;
	private JComboBox comboBox_5;
	private JComboBox comboBox_6;
	private JComboBox comboBox_7;
	private JButton btnSave;
	private JButton btnReset;
	private JButton btnLogIn;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JPasswordField passwordField;
	private JComboBox comboBox_1;
	public AdminReg() {
		getContentPane().setLayout(null);
		
		 lblName = new JLabel("Name");
		lblName.setBounds(69, 38, 56, 16);
		getContentPane().add(lblName);
		
	    lblDob = new JLabel("DOB");
		lblDob.setBounds(69, 88, 56, 16);
		getContentPane().add(lblDob);
		
		 lblGender = new JLabel("Gender");
		lblGender.setBounds(69, 135, 56, 16);
		getContentPane().add(lblGender);
		
		 lblMobile = new JLabel("Mobile");
		lblMobile.setBounds(69, 191, 56, 16);
		getContentPane().add(lblMobile);
		
		 lblEmail = new JLabel("Email");
		lblEmail.setBounds(69, 245, 56, 16);
		getContentPane().add(lblEmail);
		
		 lblJoiningdate = new JLabel("Joining_Date");
		lblJoiningdate.setBounds(69, 305, 56, 16);
		getContentPane().add(lblJoiningdate);
		
		 lblAddress = new JLabel("Address");
		lblAddress.setBounds(69, 381, 56, 16);
		getContentPane().add(lblAddress);
		
		 lblPassword = new JLabel("Password");
		lblPassword.setBounds(69, 456, 56, 16);
		getContentPane().add(lblPassword);
		
		textField = new JTextField();
		textField.setBounds(274, 32, 309, 28);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		
		String s[] = {"dd","1","2","3","4","5" };
		comboBox_1 = new JComboBox(s);
		comboBox_1.setBounds(274, 82, 63, 28);
		getContentPane().add(comboBox_1);
		
		String s1[] = {"mm","JAN","FEB","MARCH","APR","MAY" };
		 comboBox_2 = new JComboBox(s1);
		comboBox_2.setBounds(335, 82, 56, 28);
		getContentPane().add(comboBox_2);
		
		String s2[] = {"yy","1990","1991","1992","1993","1994" };
		comboBox_3 = new JComboBox(s2);
		comboBox_3.setBounds(387, 82, 63, 28);
		getContentPane().add(comboBox_3);
		
		String s3[] = {"Mail","Female"};
		 comboBox_4 = new JComboBox(s3);
		comboBox_4.setBounds(274, 128, 63, 30);
		getContentPane().add(comboBox_4);
		
		textField_1 = new JTextField();
		textField_1.setBounds(275, 184, 308, 30);
		getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(275, 239, 308, 30);
		getContentPane().add(textField_2);
		textField_2.setColumns(10);
		

		String s4[] = {"dd","1","2","3","4","5" };
		 comboBox_5 = new JComboBox(s4);
		comboBox_5.setBounds(274, 299, 63, 28);
		getContentPane().add(comboBox_5);
		
		String s5[] = {"mm","JAN","FEB","MARCH","APR","MAY" };
		 comboBox_6 = new JComboBox(s5);
		comboBox_6.setBounds(338, 299, 63, 28);
		getContentPane().add(comboBox_6);
		
		String s6[] = {"yy","1990","1991","1992","1993","1994" };
		 comboBox_7 = new JComboBox(s6);
		comboBox_7.setBounds(399, 299, 69, 28);
		getContentPane().add(comboBox_7);
		
		textField_3 = new JTextField();
		textField_3.setBounds(275, 372, 308, 35);
		getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(274, 453, 309, 35);
		getContentPane().add(passwordField);
		
		 btnSave = new JButton("SAVE");
		btnSave.setBounds(38, 546, 97, 35);
		getContentPane().add(btnSave);
		
		 btnReset = new JButton("RESET");
		btnReset.setBounds(253, 546, 97, 35);
		getContentPane().add(btnReset);
		
		btnLogIn = new JButton("LOG IN");
		btnLogIn.setBounds(458, 546, 97, 35);
		getContentPane().add(btnLogIn);
		
		comboBox_1 = new JComboBox();
		comboBox_1.setBounds(274, 82, 63, 28);
		getContentPane().add(comboBox_1);
		
		btnSave.addActionListener(this);
		btnReset.addActionListener(this);
		btnLogIn.addActionListener(this);
		}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		int x=0;
		String t1 = textField.getText();
		String t2 = textField_1.getText();
		String t3 = textField_2.getText();
		String t4 = textField_3.getText();
		char t5[] = passwordField.getPassword();
		String t6 = new String(t5);
		String t7 = (String) comboBox_1.getSelectedItem();
		String t8 = (String) comboBox_2.getSelectedItem();
		String t9 = (String) comboBox_3.getSelectedItem();
		String t10 = (String) comboBox_4.getSelectedItem();
		String t11 = (String) comboBox_5.getSelectedItem();
		String t12 = (String) comboBox_6.getSelectedItem();
		String t13 = (String) comboBox_7.getSelectedItem();
		
		if(e.getSource()==btnSave)
		{
			try
			{
				Class.forName("com.mysql.jdbc.Driver");
            	Connection con = DriverManager.getConnection("jdbc:mysql://localhost/lbmgmt","root","");
        		System.out.println("connection is:"+con);
        		PreparedStatement ps = con.prepareStatement("insert into admin_regis(Name,DOB,Gender,Mobile,Email,Joining_Date,Address,Password) values(?,?,?,?,?,?,?,?)");
        		 ps.setString(1, t1);
        		 ps.setString(2, t7);
        	     ps.setString(3, t8);
        		 ps.setString(4, t9);
        		 ps.setString(5, t10);
        		 ps.setString(6, t2);
        		 ps.setString(7, t3);
        	     ps.setString(8, t11);
        		 ps.setString(9, t12);
        		 ps.setString(10, t13);
        		 ps.setString(11, t4);
        		 ps.setString(12, t6);
        		 
        		 int rs = ps.executeUpdate();
        		 x++;
        		 if (x > 0) 
                 {
                     JOptionPane.showMessageDialog(btnSave, "Data Saved Successfully");
                    
                 }
			}
			 catch (Exception ex) 
            {
                System.out.println(ex);
            }			
		}
		else if(e.getSource()==btnReset)
		{
			textField.setText(" ");
			textField_1.setText(" ");
			textField_2.setText(" ");
			textField_3.setText(" ");
			passwordField.setText(" ");
			comboBox_1.setSelectedIndex(0);
			comboBox_2.setSelectedIndex(0);
			comboBox_3.setSelectedIndex(0);
			comboBox_4.setSelectedIndex(0);
			comboBox_5.setSelectedIndex(0);
			comboBox_6.setSelectedIndex(0);
			comboBox_7.setSelectedIndex(0);	
		}
		else 
		{
			Login li = new Login();
			li.setVisible(true);	
		}
	}
}
