import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JComboBox;

public class Login extends JFrame implements ActionListener
{
	private JTextField textField;
	private JButton btnLoginNow;
	private JLabel lblUsername;
	private JPasswordField lblPassword;
	private JLabel  lblUsertype;
	private JComboBox  comboBox;
	private JButton  btnResetNow;
	private JButton  btnNewUser;
	private JLabel lblPassword_1;
	
	public Login() 
	{
		getContentPane().setLayout(null);
			
		
		 lblUsername = new JLabel("username");
		lblUsername.setBounds(33, 63, 63, 28);
		getContentPane().add(lblUsername);
		
		 lblPassword = new JPasswordField("password");
		lblPassword.setBounds(180, 147, 325, 39);
		getContentPane().add(lblPassword);
		
	  lblUsertype = new JLabel("usertype");
		lblUsertype.setBounds(33, 246, 63, 28);
		getContentPane().add(lblUsertype);
		
		textField = new JTextField();
		textField.setBounds(180, 69, 325, 34);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		String s[] = { "SELECT","Admin","Student" };
		comboBox = new JComboBox(s);
		comboBox.setBounds(180, 249, 325, 34);
		getContentPane().add(comboBox);
		
		 btnLoginNow = new JButton("Login Now");
		btnLoginNow.setBounds(33, 379, 115, 39);
		getContentPane().add(btnLoginNow);
		
	  btnResetNow = new JButton("Reset Now");
		btnResetNow.setBounds(209, 379, 115, 39);
		getContentPane().add(btnResetNow);
		
		 btnNewUser = new JButton("New User");
		btnNewUser.setBounds(390, 379, 115, 39);
		getContentPane().add(btnNewUser);
		
		lblPassword_1 = new JLabel("password");
		lblPassword_1.setBounds(33, 158, 56, 16);
		getContentPane().add(lblPassword_1);
		
		btnLoginNow.addActionListener(this);
		btnResetNow.addActionListener(this);
		btnNewUser.addActionListener(this);	
	
    
	
	/*btnLoginNow.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			UserSection obj = new UserSection();
			obj.setVisible(true);
		}
	});*/
}
	
	
	public static void main(String[] args) 
	{
		Login l = new Login();
		l.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		int x = 0;
		String s1 = textField.getText();	
		char[] s2 =((JPasswordField) lblPassword).getPassword();
		String s3 = new String(s2);
		String s4 =  (String) comboBox.getSelectedItem();
		
		if (e.getSource() == btnLoginNow)
		{
			
			try
			{
				Class.forName("com.mysql.jdbc.Driver");
            	Connection con = DriverManager.getConnection("jdbc:mysql://localhost/lbmgmt","root","");
        		System.out.println("connection is:"+con);
        		PreparedStatement ps = con.prepareStatement("insert into login(username,password,usertype) values(?,?,?)");
        		 ps.setString(1, s1);
        		 ps.setString(2, s3);
        		 ps.setString(3, s4);
        		 int rs = ps.executeUpdate();
        		 x++;
        		 if (x > 0) 
                 {

                    
        			 
        			 
        			 if(s4.equalsIgnoreCase("Select"))
        			 {
        				 JOptionPane.showMessageDialog(getParent(), "select usertype", "ERROR", JOptionPane.ERROR_MESSAGE);
        			 }
        			 else if(s4.equalsIgnoreCase("Admin"))
        			 {
        				 AdminSection ar = new AdminSection();
        				 ar.setVisible(true);
        				 this.setVisible(false);
        				 JOptionPane.showMessageDialog(btnLoginNow, "Data Saved Successfully");
        			 }
        			 else if(s4.equalsIgnoreCase("Student"))
        			 {
        				 UserSection ur = new UserSection();
        				 ur.setVisible(true);
        				 this.setVisible(false);
        				 JOptionPane.showMessageDialog(btnLoginNow, "Data Saved Successfully");
        			 }
        			 else
        			 {
        				 
        			 }
                     
                 }

			}
			 catch (Exception ex) 
            {

                System.out.println(ex);

            }
					
					
		}
		else if (e.getSource()==btnResetNow)
		{
			textField.setText("");

			lblPassword.setText("");

			comboBox.setSelectedIndex(0);

		}
		else
		{
			 if(s4.equalsIgnoreCase("Select"))
			 {
				 JOptionPane.showMessageDialog(getParent(), "select usertype", "ERROR", JOptionPane.ERROR_MESSAGE);
			 }
			 else if(s4.equalsIgnoreCase("Admin"))
			 {
				 AdminReg ar = new AdminReg();
				 ar.setVisible(true);
				 this.setVisible(false);
			 }
			 else
			 {
				 UserReg ur = new UserReg();
				 ur.setVisible(true);
				 this.setVisible(false);
			 }
		}
		
	}
}
