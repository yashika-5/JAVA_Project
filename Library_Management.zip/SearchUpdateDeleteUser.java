import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import com.mysql.jdbc.ResultSet;

import javax.swing.JComboBox;
import javax.swing.JPasswordField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.JButton;

public class SearchUpdateDeleteUser extends JFrame implements ActionListener
{
	private JLabel  lblStudentRegistration;
	private JLabel lblEnrollment;
	private JLabel lblName;
	private JLabel lblRollno;
	private JLabel lblGender;
	private JLabel lblMobile;
	private JLabel lblEmail;
	private JLabel lblBranch;
	private JLabel lblSemester;
	private JLabel lblPassword;
	private JComboBox  comboBox;
	private JButton  btnSave;
	private JButton  btnReset;
	private JButton  btnLogIn;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JPasswordField passwordField;
	private JTextField textField_7;

	public SearchUpdateDeleteUser() {
		getContentPane().setLayout(null);
		
		 lblStudentRegistration = new JLabel("STUDENT REGISTRATION");
		lblStudentRegistration.setBounds(218, 13, 56, 16);
		getContentPane().add(lblStudentRegistration);
		
		lblEnrollment = new JLabel("Enrollment");
		lblEnrollment.setBounds(54, 56, 56, 16);
			getContentPane().add(lblEnrollment);
		
		 lblName = new JLabel("Name");
		lblName.setBounds(54, 106, 56, 16);
		getContentPane().add(lblName);
		
		lblRollno = new JLabel("Roll_no.");
		lblRollno.setBounds(54, 156, 56, 16);
		getContentPane().add(lblRollno);
		
		 lblGender = new JLabel("Gender");
		lblGender.setBounds(54, 212, 56, 16);
		getContentPane().add(lblGender);
		
		 lblMobile = new JLabel("Mobile");
		lblMobile.setBounds(54, 262, 56, 16);
		getContentPane().add(lblMobile);
		
		 lblEmail = new JLabel("Email");
		lblEmail.setBounds(54, 305, 56, 16);
		getContentPane().add(lblEmail);
		
		 lblBranch = new JLabel("Branch");
		lblBranch.setBounds(54, 362, 56, 16);
		getContentPane().add(lblBranch);
		
		 lblSemester = new JLabel("Semester");
		lblSemester.setBounds(54, 410, 56, 16);
		getContentPane().add(lblSemester);
		
		 lblPassword = new JLabel("Password");
			lblPassword.setBounds(54, 460, 56, 16);
			getContentPane().add(lblPassword);
		 
		
		textField = new JTextField();
		textField.setBounds(181, 50, 321, 29);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(181, 100, 321, 29);
		getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		String s[] = {"Mail","Female"};
		 comboBox = new JComboBox(s);
		comboBox.setBounds(179, 199, 323, 29);
		getContentPane().add(comboBox);
		
		textField_2 = new JTextField();
		textField_2.setBounds(181, 153, 321, 29);
		getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(181, 249, 321, 29);
		getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(181, 299, 321, 29);
		getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(181, 356, 321, 29);
		getContentPane().add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setBounds(181, 356, 321, 29);
		getContentPane().add(textField_6);
		textField_6.setColumns(10);
		
		
		passwordField = new JPasswordField();
		passwordField.setBounds(181, 454, 321, 29);
		getContentPane().add(passwordField);
		passwordField.setEditable(false);
		
		
		/* = new JPasswordField();
		.setBounds(181, 407, 321, 29);
		getContentPane().add();*/
		
		 btnSave = new JButton("SEARCH");
		btnSave.setBounds(33, 539, 97, 37);
		getContentPane().add(btnSave);
		
		 btnReset = new JButton("UPDATE");
		btnReset.setBounds(218, 539, 97, 37);
		getContentPane().add(btnReset);
		
		btnLogIn = new JButton("DELETE");
		btnLogIn.setBounds(405, 539, 97, 37);
		getContentPane().add(btnLogIn);
		
		textField_7 = new JTextField();
		textField_7.setBounds(179, 407, 323, 29);
		getContentPane().add(textField_7);
		textField_7.setColumns(10);
		
		
		
		btnLogIn.addActionListener(this);
	
	btnSave.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			String id=textField_2.getText();
			int flag=0;
			String query = "select * from add_user where Roll_no=?";
			try
			{
				PreparedStatement ps = DBInfo.con.prepareStatement(query);
				ps.setString(1, id);
				ResultSet res= (ResultSet) ps.executeQuery();
				while(res.next())
				{
					flag=1;
					String enrol=res.getString(1);
					String name=res.getString(2);
					String gender=res.getString(4);
					String mobile=res.getString(5);
					String email=res.getString(6);
					String branch=res.getString(7);
					String semester=res.getString(8);
					String password=res.getString(9);
					
					textField.setText(enrol);
					textField_1.setText(name);
					comboBox.setSelectedItem(gender);
					
					textField_3.setText(mobile);
					textField_4.setText(email);
					textField_5.setText(branch);
					textField_6.setText(semester);
					passwordField.setText(password);
					break;
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			if(flag==0)
			{
				JOptionPane.showMessageDialog(getParent(), "No user Found!", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
		}
	});
	
	
	btnReset.addActionListener(new ActionListener() 
	{
		public void actionPerformed(ActionEvent arg0) 
		{
			 String enrol=textField.getText();
			  String name=textField_1.getText();
			  String rollno=textField_2.getText();
			  String gender=(String)comboBox.getSelectedItem();
			  String mobile=textField_3.getText();
			  String email=textField_4.getText();
			  String branch=textField_5.getText();
			  String semester=textField_6.getText();
			  /*char t7[] = passwordField.getPassword();
				String t8 = new String(t7);*/
			  if(enrol.length()==0 || name.length()==0 || rollno.length()==0 || mobile.length()==0 || gender.equalsIgnoreCase("select") || email.length()==0 || branch.length()==0 || semester.length()==0/*t8.length()==0*/)
			  {
				  JOptionPane.showMessageDialog(SearchUpdateDeleteUser.this, "Pls fill/select all the fields", "Error", JOptionPane.ERROR_MESSAGE);				  
			  }
			  else
			  {
				  
			
String query="update add_user set id=?,Name=?,Roll_no=?,Gender=?,Mobile=?,Email=?,Branch=?,Semester=? where Roll_no=?";
			  int flag=0;
			  Connection con=DBInfo.con;
			  try
			  {
				 PreparedStatement ps=con.prepareStatement(query);
				 ps.setString(1, enrol);
				 ps.setString(2, name);
				 ps.setString(3, rollno);
				 ps.setString(4, gender);
				 ps.setString(5, mobile);
				 ps.setString(6, email);
				 ps.setString(7, branch);
				 ps.setString(8, semester);
				 ps.setString(9, rollno);
				
				 flag=ps.executeUpdate();
				 
			  }
			  catch(Exception e)
			  {
				  e.printStackTrace();
			  }
			  if(flag==1)
			  {
				  JOptionPane.showMessageDialog(SearchUpdateDeleteUser.this, "USer Data updated!!", "Success", JOptionPane.INFORMATION_MESSAGE);
			      textField.setText(null);
			      textField_1.setText(null);
			      textField_2.setText(null);
			      textField_3.setText(null);
			      textField_4.setText(null);
			      textField_5.setText(null);
			      textField_6.setText(null);
			     /* .setText(null);*/
			      comboBox.setSelectedIndex(0);
			      
			      
			  }
			  else
			  {
				  JOptionPane.showMessageDialog(SearchUpdateDeleteUser.this, "User data Not Updated", "Error", JOptionPane.ERROR_MESSAGE);
			  }
			  }
		}			  
	});
}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}	
}