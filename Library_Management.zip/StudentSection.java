import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;

public class StudentSection extends JFrame 
{
	
	private JLabel lblStudentSection;
	private JButton btnSearchBook;
	private JButton btnViewAllBooks;
	private JButton btnViewSelfAccount;
	private JButton btnChangePassword;
	private JButton btnAddFeedback;
	
	public StudentSection() {
		getContentPane().setLayout(null);
		
		lblStudentSection = new JLabel("STUDENT SECTION");
		lblStudentSection.setBounds(336, 29, 56, 16);
		getContentPane().add(lblStudentSection);
		
		btnSearchBook = new JButton("Search Book");
		btnSearchBook.setBounds(90, 82, 238, 66);
		getContentPane().add(btnSearchBook);
		
	    btnViewAllBooks = new JButton("View All Books");
		btnViewAllBooks.setBounds(336, 82, 251, 66);
		getContentPane().add(btnViewAllBooks);
		
	    btnViewSelfAccount = new JButton("View Self Account");
		btnViewSelfAccount.setBounds(90, 197, 238, 66);
		getContentPane().add(btnViewSelfAccount);
		
		btnChangePassword = new JButton("Change Password");
		btnChangePassword.setBounds(336, 197, 251, 66);
		getContentPane().add(btnChangePassword);
		
		btnAddFeedback = new JButton("ADD FEEDBACK");
		btnAddFeedback.setBounds(87, 322, 500, 66);
		getContentPane().add(btnAddFeedback);
	}

}
