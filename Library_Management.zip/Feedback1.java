import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.TextArea;

public class Feedback1 extends JFrame implements ActionListener
{

	
	private JTextField textField;
	
	private JLabel lblName;
	private JLabel  lblRollno;
	private JLabel  lblMessage;
	
	private JButton  btnSubmit;
	private JTextField textField_1;
	private TextArea textArea;
	
	
	
	public Feedback1() 
	{
		getContentPane().setLayout(null);
			
		
		 lblName = new JLabel("Name");
		lblName.setBounds(33, 63, 63, 28);
		getContentPane().add(lblName);
		

		 lblRollno = new JLabel("Roll No");
		lblRollno.setBounds(33, 146, 49, 39);
		getContentPane().add(lblRollno);
		
		
		
		/* lblPassword = new JPasswordField("password");
		lblPassword.setBounds(180, 147, 325, 39);
		getContentPane().add(lblPassword);*/
		
	  lblMessage = new JLabel("Message");
		lblMessage.setBounds(33, 246, 63, 28);
		getContentPane().add(lblMessage);
		
		textField = new JTextField();
		textField.setBounds(177, 69, 328, 39);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		/*String s[] = { "SELECT","Admin","Student" };
		comboBox = new JComboBox(s);
		comboBox.setBounds(180, 249, 325, 34);
		getContentPane().add(comboBox);*/
		
		 btnSubmit = new JButton("Submit");
		btnSubmit.setBounds(204, 418, 115, 39);
		getContentPane().add(btnSubmit);
		
		textField_1 = new JTextField();
		textField_1.setBounds(177, 146, 328, 39);
		getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textArea = new TextArea();
		textArea.setBounds(179, 208, 325, 145);
		getContentPane().add(textArea);
		
	
		btnSubmit.addActionListener(this);
		
    
	
	/*btnLoginNow.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			UserSection obj = new UserSection();
			obj.setVisible(true);
		}
	});*/
}
	
	
	public static void main(String[] args) 
	{
		Login l = new Login();
		l.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		int x = 0;
		String s1 = textField.getText();	
		String s2 = textField_1.getText();
		String s4 = textArea.getText();
		
		if (e.getSource() == btnSubmit)
		{
			
			try
			{
				Class.forName("com.mysql.jdbc.Driver");
            	Connection con = DriverManager.getConnection("jdbc:mysql://localhost/lbmgmt","root","");
        		System.out.println("connection is:"+con);
        		PreparedStatement ps = con.prepareStatement("insert into feedback(name,roll_no,feedback) values(?,?,?)");
        		 ps.setString(1, s1);
        		 ps.setString(2, s2);
        		 ps.setString(3, s4);
        		 int rs = ps.executeUpdate();
        		 x++;
        		 if (x > 0) 
                 {

                     JOptionPane.showMessageDialog(btnSubmit, "Data Saved Successfully");
                     
                 }

			}
			 catch (Exception ex) 
            {

                System.out.println(ex);

            }
					
					
		}
		
		
		
	}
}
