import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JPasswordField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.JButton;
import java.awt.BorderLayout;

public class UserSection extends JFrame implements ActionListener
{
	public UserSection() {
		
		JButton btnIssuedBooks = new JButton("Issue Book ?");
		btnIssuedBooks.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				IssueBookForm obj = new IssueBookForm();
				obj.setVisible(true);
			}
		});
		getContentPane().add(btnIssuedBooks, BorderLayout.NORTH);
		
		JButton btnSubmitBooks = new JButton("View all Books");
		btnSubmitBooks.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			SearchBy obj = new SearchBy();
				obj.setVisible(true);
			}
		});
		
		
		getContentPane().add(btnSubmitBooks, BorderLayout.WEST);
		
		JButton btnFeedback = new JButton("Feedback");
		btnFeedback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Feedback1 obj = new Feedback1();
				obj.setVisible(true);
			}
		});
		
		
		getContentPane().add(btnFeedback, BorderLayout.EAST);
		
		JButton btnChangePassword = new JButton("Change Password");
		
		btnChangePassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ChangePassword obj = new ChangePassword();
				obj.setVisible(true);
			}
		});
		
		
		
		
		getContentPane().add(btnChangePassword, BorderLayout.SOUTH);
		
		JButton btnViewProfile = new JButton("View Profile");
		btnViewProfile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				UserReg obj = new UserReg();
				obj.setVisible(true);
			}
		});
		
		
		getContentPane().add(btnViewProfile, BorderLayout.CENTER);
		
		
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
}
