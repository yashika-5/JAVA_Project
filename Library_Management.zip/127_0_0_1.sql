-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 04, 2019 at 12:23 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admin`
--
CREATE DATABASE IF NOT EXISTS `admin` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `admin`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`email`, `password`) VALUES
('admin@gmail.com', '12345'),
('admin@gmail.com', '12345');
--
-- Database: `detail`
--
CREATE DATABASE IF NOT EXISTS `detail` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `detail`;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `city` enum('jaipur','udaipur','jodhpur') NOT NULL,
  `gender` enum('male','female') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `lname`, `city`, `gender`) VALUES
(0, 'pratul', 'gupta', 'jodhpur', 'male');
--
-- Database: `details`
--
CREATE DATABASE IF NOT EXISTS `details` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `details`;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(10) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `confirm` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `checkbox` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `fname`, `lname`, `email`, `password`, `confirm`, `mobile`, `checkbox`) VALUES
(1, 'yashu', 'shrama', 'yashikagupta@gmail.com', '123456', '123456', '355464', 1),
(1, 'yashu', 'shrama', 'yashikagupta@gmail.com', '123456', '123456', '355464', 1);

-- --------------------------------------------------------

--
-- Table structure for table `adminy`
--

CREATE TABLE `adminy` (
  `id` int(10) NOT NULL,
  `name` varchar(10) NOT NULL,
  `lname` varchar(10) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `mobile` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminy`
--

INSERT INTO `adminy` (`id`, `name`, `lname`, `email`, `password`, `city`, `mobile`) VALUES
(1, 'yashu', 'gupta', 'yashikagupta@gmail.c', '123456', 'jaipur', '27498478'),
(2, '', '', '', '', '', ''),
(3, '', '', '', '', '', ''),
(4, 'kjhkjh', 'l;kj;l', 'a@gmail.com', '78975464', 'rajgrah', '5646546544'),
(5, 'kjhkjh', 'l;kj;l', 'a@gmail.com', '78975464', 'rajgrah', '5646546544'),
(6, 'yashikagup', 'gupta', 'yashikagupta@gmail.c', '12345', 'rajgrah', '325346756'),
(7, 'yashikagup', 'gupta', 'yashikagupta@gmail.c', '12345', 'rajgrah', '325346756'),
(8, 'tanu', 'singh', 'tanu@gmail.com', '12345', 'jaipur', '123456789'),
(9, 'tanu', 'singh', 'tanu@gmail.com', '12345', 'jaipur', '123456789'),
(10, 'Punit', 'shah', 'tanugupta@gmail.com', '1234', 'jaipur', '12345345'),
(11, 'Punit', 'shah', 'tanugupta@gmail.com', '1234', 'jaipur', '12345345'),
(12, 'Punit', 'shah', 'tanugupta@gmail.com', '1234', 'jaipur', '12345345'),
(13, 'Punit', 'shah', 'tanugupta@gmail.com', '1234', 'jaipur', '12345345'),
(14, 'Punit', 'shah', 'tanugupta@gmail.com', '1234', 'jaipur', '12345345'),
(15, 'yashu', 'gupta', 'yashikagupta@gmail.c', '123456', 'jaipur', '27498478');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `s_no` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`s_no`, `email`, `pass`) VALUES
(1, 'admin@gmail.com', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminy`
--
ALTER TABLE `adminy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`s_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminy`
--
ALTER TABLE `adminy`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Database: `first`
--
CREATE DATABASE IF NOT EXISTS `first` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `first`;

-- --------------------------------------------------------

--
-- Table structure for table `first`
--

CREATE TABLE `first` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `city` enum('jaipur','udaipur',',jodhpur') NOT NULL,
  `gender` enum('mail','female') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `first`
--

INSERT INTO `first` (`id`, `name`, `lname`, `city`, `gender`) VALUES
(0, 'giugikuk', 'fuyfiyj', 'jaipur', 'mail'),
(0, 'kfyfyujgf', 'fuyfdyjd', 'jaipur', 'mail'),
(0, 'Yash', 'shah', 'udaipur', 'mail'),
(0, 'Yashu', 'savy', 'jaipur', 'mail');
--
-- Database: `joins`
--
CREATE DATABASE IF NOT EXISTS `joins` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `joins`;

-- --------------------------------------------------------

--
-- Table structure for table `crap`
--

CREATE TABLE `crap` (
  `roll_no` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `age` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `crap`
--

INSERT INTO `crap` (`roll_no`, `name`, `address`, `age`) VALUES
(1, 'payal', '13 Kisan MArg', 2),
(2, 'payall', '13 san MArg', 7),
(3, 'paya', '13 Kis MArg', 8),
(4, 'pay', '13 Kisn MArg', 2);

-- --------------------------------------------------------

--
-- Table structure for table `joins`
--

CREATE TABLE `joins` (
  `roll_no` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `age` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `prap`
--

CREATE TABLE `prap` (
  `roll_no` int(11) NOT NULL,
  `age` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prap`
--

INSERT INTO `prap` (`roll_no`, `age`) VALUES
(1, 2),
(2, 7),
(3, 8),
(4, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `crap`
--
ALTER TABLE `crap`
  ADD PRIMARY KEY (`roll_no`);

--
-- Indexes for table `prap`
--
ALTER TABLE `prap`
  ADD PRIMARY KEY (`roll_no`);
--
-- Database: `lab1`
--
CREATE DATABASE IF NOT EXISTS `lab1` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `lab1`;

-- --------------------------------------------------------

--
-- Table structure for table `php`
--

CREATE TABLE `php` (
  `name` varchar(100) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `sex` enum('male','female') NOT NULL,
  `id` int(100) NOT NULL,
  `skill` enum('HTML','CSS','CPP','JAVA') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `php`
--

INSERT INTO `php` (`name`, `pass`, `sex`, `id`, `skill`) VALUES
('yashika', 'gupta', 'male', 0, 'HTML'),
('yashika', 'gupta', 'male', 0, 'HTML'),
('yashika', 'gupta', 'male', 0, 'HTML'),
('dgdfb', 'qwert', 'male', 0, 'HTML'),
('', '', 'male', 0, 'HTML'),
('', '', '', 0, 'HTML'),
('ysh', 'shfh', 'female', 0, 'HTML'),
('ysh', 'shfh', 'female', 0, 'HTML'),
('ysh', 'shfh', 'female', 0, 'HTML'),
('ysh', 'shfh', 'female', 0, 'HTML'),
('ysh', 'shfh', 'female', 0, 'HTML');
--
-- Database: `lbmgmt`
--
CREATE DATABASE IF NOT EXISTS `lbmgmt` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `lbmgmt`;

-- --------------------------------------------------------

--
-- Table structure for table `add_user`
--

CREATE TABLE `add_user` (
  `id` int(11) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Roll_no` varchar(20) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `Mobile` varchar(20) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Branch` varchar(20) NOT NULL,
  `Semester` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_user`
--

INSERT INTO `add_user` (`id`, `Name`, `Roll_no`, `Gender`, `Mobile`, `Email`, `Branch`, `Semester`, `Password`) VALUES
(1, 'qqqqqqq', '23', 'Mail', '455735345', 'sfsfse', 'we', '1', '12345'),
(2, 'yashika', '93', 'Mail', '2347926932', 'yashika@gmail.com', 'Icse', '2', '999'),
(3, 'yash', '92', 'mail', '687946546', 'yash@hmaikjm', 'cs', '7', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `admin_regis`
--

CREATE TABLE `admin_regis` (
  `id` int(11) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `DOB` varchar(30) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `Mobile` varchar(20) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Joining_Date` varchar(30) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `author`
--

CREATE TABLE `author` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `author`
--

INSERT INTO `author` (`id`, `name`) VALUES
(1, 'prachi'),
(2, 'raj'),
(3, 'raj'),
(4, 'GFJG'),
(5, 'JAI'),
(6, 'JP SHARMA'),
(7, 'GIRISH'),
(8, 'QWERTT');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `Book_id` int(20) NOT NULL,
  `Title` varchar(30) NOT NULL,
  `Author` varchar(30) NOT NULL,
  `Publisher` varchar(30) NOT NULL,
  `Category` varchar(30) NOT NULL,
  `Subject` varchar(30) NOT NULL,
  `Isbn` int(20) NOT NULL,
  `Edition` varchar(30) NOT NULL,
  `Price` varchar(20) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`Book_id`, `Title`, `Author`, `Publisher`, `Category`, `Subject`, `Isbn`, `Edition`, `Price`, `quantity`) VALUES
(345666, 'dfsdf', 'GIRISH', 'PJP', 'HARD PROGRAMS', 'JAVA LANGUAGE', 3456, '456', '34', 23),
(189527, 'php', 'QWERTT', 'OPO', 'HARD PROGRAMS', 'PYTHON', 678, '354', '587', 8);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'C'),
(2, 'JAVA'),
(3, 'HARD PROGRAMS'),
(4, 'RUBY');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `roll_no` int(20) NOT NULL,
  `feedback` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `roll_no`, `feedback`) VALUES
(1, 'yashika', 93, 'whkur wjehksj hslefhk lisefn'),
(2, 'yashika', 93, 'hlkhl\r\nbkjvbkjb kjbjk'),
(3, 'yashu', 93, 'agfku akbfkef \r\nasfukaefbjwegf');

-- --------------------------------------------------------

--
-- Table structure for table `issued_book`
--

CREATE TABLE `issued_book` (
  `id` int(11) NOT NULL,
  `Book_id` int(30) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Roll_no` int(20) NOT NULL,
  `Contact` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `issued_book`
--

INSERT INTO `issued_book` (`id`, `Book_id`, `Name`, `Roll_no`, `Contact`) VALUES
(1, 345666, 'Yashika', 93, 576987),
(2, 345666, 'Yashu', 93, 2798429);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `usertype` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `usertype`) VALUES
('yashu', 'yashu123', 'Student'),
('prachi', 'prachi123', 'Student'),
('tanu', 'tanu123', 'Student'),
('yashu', 'yashu123', 'Student'),
('tanut', 'tanut123', 'Admin'),
('tanut', 'tanut123', 'Admin'),
('tanut', 'tanut123', 'Admin'),
('yashu', 'yashu123', 'Student'),
('yashu', 'yashu123', 'Student'),
('yashu', 'password', 'Student'),
('yashu', 'password', 'Student'),
('yashu', 'password', 'SELECT'),
('yashu', 'password', 'Student'),
('yashu', 'password', 'SELECT'),
('yashu', 'password', 'SELECT'),
('yashu', 'password', 'SELECT'),
('yashu', 'password', 'SELECT'),
('yashu', 'password', 'Student'),
('yashu', 'password', 'SELECT'),
('yashu', 'password', 'SELECT'),
('yashu', 'password', 'SELECT'),
('yashu', 'password', 'SELECT'),
('yashu', 'password', 'Student'),
('yashu', 'password', 'SELECT'),
('yashu', 'password', 'Student'),
('yashu', 'password', 'Student'),
('yashu', 'password', 'Student'),
('yashu', 'password', 'Student'),
('yashu', 'password', 'Student'),
('yashu', 'password', 'SELECT'),
('yashu', 'password', 'Student'),
('yashu', 'password', 'Student'),
('yashu', 'password', 'Student'),
('yashu', 'password', 'Student'),
('yashu', 'password', 'SELECT'),
('yashu', 'password', 'Student'),
('yashu', 'password', 'Student'),
('yashu', 'password', 'SELECT'),
('yashu', 'password', 'SELECT'),
('yashu', 'password', 'SELECT'),
('yashu', 'password', 'SELECT'),
('yashu', 'password', 'SELECT'),
('yashu', 'password', 'SELECT'),
('tanut', 'tanut123', 'Admin'),
('yashu', 'yashu123', 'Student'),
('yashu', 'password', 'SELECT'),
('yashu', 'password', 'Student'),
('yashu', 'password', 'Student'),
('yashu', 'password', 'Student'),
('yashu', 'yashu123', 'SELECT'),
('yashu', 'yashu123', 'SELECT'),
('yashu', 'yashu123', 'Admin'),
('yashu', 'yashu123', 'SELECT'),
('yashu', 'yashu123', 'Admin'),
('yashu', 'yashu123', 'SELECT'),
('yashu', 'yashu123', 'Admin'),
('yashu', 'password', 'Student'),
('yashu', 'password', 'Student');

-- --------------------------------------------------------

--
-- Table structure for table `publisher`
--

CREATE TABLE `publisher` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `publisher`
--

INSERT INTO `publisher` (`id`, `name`) VALUES
(1, 'FJJ'),
(2, 'PJP'),
(3, 'JPJ'),
(4, 'WWW'),
(5, 'OPO');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`id`, `name`) VALUES
(1, 'PROGRAMS'),
(2, 'JAVA LANGUAGE'),
(3, 'PYTHON'),
(4, 'CODING');

-- --------------------------------------------------------

--
-- Table structure for table `submit_book`
--

CREATE TABLE `submit_book` (
  `id` int(11) NOT NULL,
  `Book_id` int(20) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Roll_no` int(20) NOT NULL,
  `Contact` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `submit_book`
--

INSERT INTO `submit_book` (`id`, `Book_id`, `Name`, `Roll_no`, `Contact`) VALUES
(1, 189527, 'yashu', 93, 3475868);

-- --------------------------------------------------------

--
-- Table structure for table `user_regis`
--

CREATE TABLE `user_regis` (
  `id` int(11) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Roll_no` int(20) NOT NULL,
  `Gender` varchar(30) NOT NULL,
  `Mobile` int(20) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Branch` varchar(20) NOT NULL,
  `Semester` varchar(20) NOT NULL,
  `Password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_regis`
--

INSERT INTO `user_regis` (`id`, `Name`, `Roll_no`, `Gender`, `Mobile`, `Email`, `Branch`, `Semester`, `Password`) VALUES
(1, 'yashika', 12, 'Female', 1218946, 'akjd@gmail.com', 'cse', '2', '12121');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_user`
--
ALTER TABLE `add_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_regis`
--
ALTER TABLE `admin_regis`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `author`
--
ALTER TABLE `author`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `issued_book`
--
ALTER TABLE `issued_book`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `publisher`
--
ALTER TABLE `publisher`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `submit_book`
--
ALTER TABLE `submit_book`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_regis`
--
ALTER TABLE `user_regis`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_user`
--
ALTER TABLE `add_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `admin_regis`
--
ALTER TABLE `admin_regis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `author`
--
ALTER TABLE `author`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `issued_book`
--
ALTER TABLE `issued_book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `publisher`
--
ALTER TABLE `publisher`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `submit_book`
--
ALTER TABLE `submit_book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_regis`
--
ALTER TABLE `user_regis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Database: `login`
--
CREATE DATABASE IF NOT EXISTS `login` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `login`;

-- --------------------------------------------------------

--
-- Table structure for table `exercise_log`
--

CREATE TABLE `exercise_log` (
  `id` int(11) NOT NULL,
  `TYPE` text,
  `minutes` int(11) DEFAULT NULL,
  `calories` int(11) DEFAULT NULL,
  `heart_rate` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exercise_log`
--

INSERT INTO `exercise_log` (`id`, `TYPE`, `minutes`, `calories`, `heart_rate`) VALUES
(1, 'biking', 30, 100, 110);

-- --------------------------------------------------------

--
-- Table structure for table `groceries`
--

CREATE TABLE `groceries` (
  `id` int(11) NOT NULL,
  `NAME` text,
  `quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(0, 'testuser', 'testuserpass');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `exercise_log`
--
ALTER TABLE `exercise_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groceries`
--
ALTER TABLE `groceries`
  ADD PRIMARY KEY (`id`);
--
-- Database: `loginsystem`
--
CREATE DATABASE IF NOT EXISTS `loginsystem` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `loginsystem`;

-- --------------------------------------------------------

--
-- Table structure for table `exercise_log`
--

CREATE TABLE `exercise_log` (
  `id` int(11) NOT NULL,
  `TYPE` text,
  `minutes` int(11) DEFAULT NULL,
  `calories` int(11) DEFAULT NULL,
  `heart_rate` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exercise_logs`
--

CREATE TABLE `exercise_logs` (
  `id` int(11) NOT NULL,
  `TYPE` text,
  `minutes` int(11) DEFAULT NULL,
  `calories` int(11) DEFAULT NULL,
  `heart_rate` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `grocery`
--

CREATE TABLE `grocery` (
  `id` int(11) NOT NULL,
  `NAME` text,
  `quantity` int(11) DEFAULT NULL,
  `aisle` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grocery`
--

INSERT INTO `grocery` (`id`, `NAME`, `quantity`, `aisle`) VALUES
(1, 'Banana', 4, 7),
(2, 'Bread', 3, 2),
(3, 'Melon', 2, 4),
(4, 'Orange', 1, 6),
(5, 'Pea', 7, 5),
(6, 'Apple', 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `newtable`
--

CREATE TABLE `newtable` (
  `column1` varchar(32) DEFAULT NULL,
  `column2` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_first` varchar(256) NOT NULL,
  `user_last` varchar(256) NOT NULL,
  `user_email` varchar(256) NOT NULL,
  `user_uid` varchar(256) NOT NULL,
  `user_pwd` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `exercise_log`
--
ALTER TABLE `exercise_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exercise_logs`
--
ALTER TABLE `exercise_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `grocery`
--
ALTER TABLE `grocery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `exercise_logs`
--
ALTER TABLE `exercise_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Database: `notes`
--
CREATE DATABASE IF NOT EXISTS `notes` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `notes`;

-- --------------------------------------------------------

--
-- Table structure for table `add_user`
--

CREATE TABLE `add_user` (
  `id` int(11) NOT NULL,
  `first` varchar(25) NOT NULL,
  `last` varchar(20) NOT NULL,
  `email` varchar(25) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_user`
--

INSERT INTO `add_user` (`id`, `first`, `last`, `email`, `password`) VALUES
(1, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `daily_log`
--

CREATE TABLE `daily_log` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `file_uploader` varchar(20) NOT NULL,
  `file_uploaded_to` varchar(30) NOT NULL,
  `file_title` varchar(40) NOT NULL,
  `file_description` varchar(50) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(255) NOT NULL DEFAULT 'not approved yet'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `daily_log`
--

INSERT INTO `daily_log` (`id`, `user_id`, `file_uploader`, `file_uploaded_to`, `file_title`, `file_description`, `date`, `modified_date`, `status`) VALUES
(1, 0, '', '', 'php', 'not required', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'not approved yet'),
(2, 0, '', '', 'chair', 'robotic chair', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'not approved yet'),
(3, 0, '', '', 'JAva', 'java yypte', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'not approved yet'),
(4, 0, 'simar', 'EE', 'Unity', 'Nothing', '2018-10-02 22:43:10', '2018-10-02 15:43:10', 'approved'),
(5, 0, 'payal', 'IT', 'Builder', 'no need', '2018-10-03 01:32:15', '2018-10-02 18:32:15', 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `priority` enum('High','Low') NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` varchar(245) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `username`, `priority`, `subject`, `message`) VALUES
(1, 'payal', '', ' regarding message system', 'this project has higher priority than other project so you have to complete it in given time.'),
(2, 'payal', '', ' regarding message system', 'slkef lenslkg nrdglkg kndrglkg'),
(3, 'simar', '', ' regarding noise ', 'hello simar , this project has higher priority.'),
(4, 'simar', '', ' regarding college notes', 'hope so'),
(5, 'simar', '', ' slknlcksd nlsakncf leads', 'whatsp'),
(6, 'simar', '', ' skdnfl slfkdn', 'hey'),
(7, 'simar', '', ' alsmd alsmd;as', 'gaksdb,'),
(8, 'simar', '', ' alsmd alsmd;as', 'gaksdb,'),
(9, 'simar', '', ' ktttttttttttttttttt', ';l21ue98bd93d97wqi'),
(10, 'simar', '', ' ktttttttttttttttttt', ';l21ue98bd93d97wqi'),
(11, 'simar', '', ' plese', 'asmla lwadl alwdjld lwadnsl'),
(12, 'simar', '', ' regarding college notes gallery', 'alwknd wlkenfl welnfwl wlenflwef'),
(13, 'simar', '', ' slknlcksd nlsakncf leads', 'sfz111111111111111111'),
(14, 'payal', '', ' mw;ejf;', 'wejfowje wefnlwejf'),
(15, 'simar', '', ' yyyyyyyyyyyyyyyy', 'ppppppppppppppp'),
(16, 'simar', '', ' ', ''),
(17, 'simar', '', ' php project', 'jldi do'),
(18, 'prateek', '', ' hi', 'hiniijijijijijijij'),
(19, 'simar', '', ' hgvghgv', 'fgvghv dear prateek'),
(20, 'simar', '', ' regarding message system', 'dfcghjkdfghjklfghjklggggggggggggggggggggggggggg'),
(21, 'simar', '', ' check ', 'hellllooooo'),
(22, 'simar', '', 'check ', 'hellllooooo'),
(23, 'simar', '', 'last try', 'should be happen'),
(24, 'payal', 'Low', 'hey', 'hello'),
(25, '', 'High', '', ''),
(26, '', 'High', '', ''),
(27, '', 'High', '', ''),
(28, '', 'High', '', ''),
(29, '', 'High', '', ''),
(30, '', 'High', '', ''),
(31, 'sona', '', '', ''),
(32, 'naveen', '', '', ''),
(33, 'kriya', '', '', ''),
(34, 'simmi', '', '', ''),
(35, 'simmi', '', '', ''),
(36, 'tanuja', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tech_detail`
--

CREATE TABLE `tech_detail` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varbinary(30) NOT NULL,
  `username` varchar(20) NOT NULL,
  `current_skills` varchar(100) NOT NULL,
  `new_skills` varchar(100) NOT NULL,
  `switched_company` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `uploads`
--

CREATE TABLE `uploads` (
  `file_id` int(11) NOT NULL,
  `file_name` varchar(225) NOT NULL,
  `file_description` text NOT NULL,
  `file_type` varchar(225) NOT NULL,
  `file_uploader` varchar(225) NOT NULL,
  `file_uploaded_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `file_uploaded_to` varchar(225) NOT NULL,
  `file` varchar(225) NOT NULL,
  `status` varchar(225) NOT NULL DEFAULT 'not approved yet'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uploads`
--

INSERT INTO `uploads` (`file_id`, `file_name`, `file_description`, `file_type`, `file_uploader`, `file_uploaded_on`, `file_uploaded_to`, `file`, `status`) VALUES
(57, 'demo previer', 'demo', 'pdf', 'user', '2017-07-19 05:08:23', 'Computer Science', '578090.pdf', 'approved'),
(56, 'teacher3 demo', 'demo', 'txt', 'teacher2', '2017-07-19 05:08:16', 'Mechanical', '565834.txt', 'approved'),
(55, 'teacher title', 'demo desc', 'zip', 'teacher', '2017-07-22 06:02:02', 'Mechanical', '898387.zip', 'approved'),
(58, 'phpp demo', 'ppph demo', 'pdf', 'anirban', '2018-10-02 21:11:49', 'Computer Science', '69321.pdf', 'approved'),
(54, 'user title', 'user desc', 'zip', 'student', '2017-07-19 05:08:28', 'Computer Science', '848114.zip', 'approved'),
(53, 'demo title ..', 'demo desc...', 'zip', 'user2', '2017-07-19 04:54:36', 'Electrical', '305047.zip', 'not approved yet'),
(52, 'demo title', 'demo desc......', 'pdf', 'user1', '2017-07-22 06:02:22', 'Electrical', '845248.pdf', 'approved'),
(51, 'demo 3', 'demo 3 desc....', 'pdf', 'user3', '2017-07-22 06:02:15', 'Computer Science', '437056.pdf', 'approved'),
(50, 'demo2', 'demo desc 2...', 'ppt', 'user3', '2017-07-22 06:02:36', 'Computer Science', '800920.ppt', 'approved'),
(49, 'demo title', 'demo description', 'docx', 'user3', '2017-07-19 05:08:13', 'Computer Science', '502238.docx', 'approved'),
(59, 'designing', 'nothing much', 'pdf', 'anshul', '2018-09-29 00:02:24', 'Design', '161601.pdf', 'not approved yet'),
(60, 'Chatbot', 'it is based on a robot.', 'pdf', 'prateek', '2018-09-29 04:00:09', 'culture', '775201.pdf', 'not approved yet'),
(61, 'bhamashah', 'asnflakfnlalsnflfn', 'txt', 'payal', '2018-09-29 05:57:20', 'IT', '172995.txt', 'not approved yet'),
(62, 'Artificial Intell', 'this will work.', 'pdf', 'simar', '2018-09-29 16:51:59', 'EE', '473461.pdf', 'not approved yet');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(225) NOT NULL,
  `name` varchar(225) NOT NULL,
  `about` varchar(300) NOT NULL DEFAULT 'N/A',
  `role` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `token` varchar(225) NOT NULL,
  `gender` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `course` varchar(225) NOT NULL,
  `image` varchar(225) NOT NULL DEFAULT 'profile.jpg',
  `joindate` varchar(225) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `name`, `about`, `role`, `email`, `token`, `gender`, `password`, `course`, `image`, `joindate`) VALUES
(24, 'user', 'user1', 'N/A', 'teacher', 'user@ndndn.cbbc', '', 'Male', '$2y$10$Z1H.ruYjbMSp07EhejzS0O1Fr7PgFdjqbWmtu7/j68TXr55gZ2Msu', 'Computer Science', '107095.jpg', 'July 19, 2017'),
(23, 'teacher2', 'teacher2', 'N/A', 'teacher', 'teacher2hdh@n.fncn', '', 'Male', '$2y$10$rCjs9AHzUSVmITcRJJosgeUxJA5gJ7dZfY16ij/1xf9bzxmFAZzMq', 'Mechanical', '895979.jpg', 'July 19, 2017'),
(22, 'teacher', 'teacher', 'N/A', 'teacher', 'teacher@bfbf.nncn', '', 'Male', '$2y$10$jAk4uQiBQ6b03EVZ0/9i1ucWdNFcVV1dXYj4X2f8uZ4Xd81hBkauG', 'Mechanical', '839669.jpg', 'July 19, 2017'),
(12, 'root', 'admin root', 'N/A', 'admin', 'root@gmail.com', '', 'N/A', '$2y$10$UExd.f8vQXogrZELXF8KGulQJKUn32p8x4B5SVQ7V/D6.mrSAkAjW', 'Computer Science', 'profile.jpg', '2000-01-01'),
(21, 'student', 'student4', 'N/A', 'teacher', 'user4@gmai.com', '', 'Female', '$2y$10$8NTdzG/HXZq5d23o9IqteOY3vWZg75hC99tkuU60/ivcqiQ1sho6.', 'Computer Science', 'profile.jpg', 'July 19, 2017'),
(18, 'user1', 'User 1', 'N/A', 'teacher', 'user1@gmail.com', '', 'Male', '$2y$10$LS76ATZ/jRN/M/pDAyfJmOkNI1MpF08T8NzjNcK.MZKpbjkeMKdMC', 'Electrical', '180812.jpg', 'July 19, 2017'),
(19, 'user2', 'user2', 'i am user', 'student', 'user2@gmail.com', '', 'Female', '$2y$10$OCazXxzd6FM.V2afvmapqOGxVj8Gac3zN.2tlmuO1v1Y3103dqhti', 'Electrical', 'profile.jpg', 'July 19, 2017'),
(20, 'user3', 'user3', 'N/A', 'teacher', 'user3@gmail.com', '', 'Male', '$2y$10$DEKxq9z1r8sWPSzj2XL7LOlT.cUWZv1EbTGZlrXO2VkiBbIuRfoBu', 'Computer Science', 'profile.jpg', 'July 19, 2017'),
(26, 'user6', 'user6', 'N/A', 'teacher', 'user6@gmail.com', '', 'Male', '$2y$10$8OKm1GXZtf4vWTafLHgmjeFls3SvCTWiyXJVhnPr4XOYLeXGOPybW', 'Computer Science', '382911.jpg', 'July 22, 2017'),
(25, 'anirban', 'Anirban', 'N/A', 'teacher', 'anirban.root@gmail.com', 'fbab3eec077a38d565e9c93442178b7d', 'Male', '$2y$10$h4i29DiU8zeLT7EOMLka3uTTCtAxtU.DAExBhywJF3SIRwpHq4wuG', 'Computer Science', '441172.jpg', 'July 20, 2017'),
(27, 'user9', 'hfg gghh', 'N/A', 'teacher', 'ffhhgh@jjdj.vjjv', '', 'Male', '$2y$10$Z1hwjfIGjC8/Zv0NFy/BDO0W.A6K4ZAWLPrW8.himo7YAi0sC7Kjy', 'Computer Science', 'profile.jpg', 'July 22, 2017'),
(28, 'payal', 'payal gupta', 'N/A', 'teacher', 'payal@gmail.com', '', 'Female', '$2y$10$vU5MIxp16Nhvona3nYtXy.2eHKdPXzxeA4QlW1NngauupjHFS2efy', 'IT', 'profile.jpg', 'September 25, 2018'),
(29, 'anshul', 'anshul', 'N/A', 'teamleader', 'anshul@gmail.com', '', 'Male', '$2y$10$FQchZlzw742rcuVhBbkYhuyWKo1sdqnv0jNO3SBfREs294TVbxAYK', 'Design', 'profile.jpg', 'September 29, 2018'),
(30, 'prateek', 'prateek', 'N/A', 'teamleader', 'prateek@gmail.com', '', 'Male', '$2y$10$uZwzepCu1Na/9hCUB4JO3.7SWRuscUPW2KPt31vhkEGfvANNGSXkm', 'culture', 'profile.jpg', 'September 29, 2018'),
(31, 'simar', 'simar', 'N/A', 'employee', 'simar@gmail.com', '', 'Female', '$2y$10$DiAvwEpJxBswmHMH4DY78OrrJb58V.7O/vD.h4rky.9HeC1EX5S82', 'EE', 'profile.jpg', 'September 29, 2018'),
(32, '', '', 'N/A', '', '', '', '', '', '', 'profile.jpg', ''),
(33, '', '', 'N/A', '', '', '', '', '', '', 'profile.jpg', ''),
(34, '', '', 'N/A', '', '', '', '', '', '', 'profile.jpg', ''),
(35, '', '', 'N/A', '', '', '', '', '', '', 'profile.jpg', ''),
(36, 'sona', 'sona gupta', 'N/A', '', 'sona@gmail.com', '', '', 'sona123', '', 'profile.jpg', ''),
(37, 'naveen', 'naveen jain', 'N/A', '', 'naveen@gmail.com', '', '', 'naveen123', '', 'profile.jpg', ''),
(38, 'kriya', 'kriya gupta', 'N/A', '', 'kriya@gmail.com', '', '', 'kriya123', '', 'profile.jpg', ''),
(39, 'harshita', 'harshita', 'N/A', 'employee', 'harshita@gmail.com', '', 'Female', '$2y$10$1/7MFxYIvVwYo358d98nfuG.8MHXM/AWQG.dSkVjfn01LHKLrg4sG', 'Design', 'profile.jpg', 'October 5, 2018'),
(40, 'simmi', 'simmi', 'N/A', '', 'simmi@gmail.com', '', '', 'simmi123', '', 'profile.jpg', ''),
(41, 'tanuja', 'tanuja joshi', 'N/A', '', 'tanuja@gmail.com', '', '', '$2y$10$NqAey4LRPBcBR/3BsjeitO4k8msjrhMlMHgxPTH.a73TMbBYXYjIK', '', 'profile.jpg', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_user`
--
ALTER TABLE `add_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `daily_log`
--
ALTER TABLE `daily_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tech_detail`
--
ALTER TABLE `tech_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uploads`
--
ALTER TABLE `uploads`
  ADD PRIMARY KEY (`file_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_user`
--
ALTER TABLE `add_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `daily_log`
--
ALTER TABLE `daily_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `tech_detail`
--
ALTER TABLE `tech_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `uploads`
--
ALTER TABLE `uploads`
  MODIFY `file_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
--
-- Database: `phplessons`
--
CREATE DATABASE IF NOT EXISTS `phplessons` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `phplessons`;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `topic` int(11) NOT NULL,
  `content` int(11) NOT NULL,
  `date` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Database: `phpmyadmin`
--
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `phpmyadmin`;

-- --------------------------------------------------------

--
-- Table structure for table `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(11) NOT NULL,
  `dbase` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `query` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Table structure for table `pma__central_columns`
--

CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_length` text COLLATE utf8_bin,
  `col_collation` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) COLLATE utf8_bin DEFAULT '',
  `col_default` text COLLATE utf8_bin
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Table structure for table `pma__column_info`
--

CREATE TABLE `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `column_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__designer_settings`
--

CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `settings_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

-- --------------------------------------------------------

--
-- Table structure for table `pma__export_templates`
--

CREATE TABLE `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `export_type` varchar(10) COLLATE utf8_bin NOT NULL,
  `template_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `template_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

-- --------------------------------------------------------

--
-- Table structure for table `pma__favorite`
--

CREATE TABLE `pma__favorite` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

-- --------------------------------------------------------

--
-- Table structure for table `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sqlquery` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__navigationhiding`
--

CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

-- --------------------------------------------------------

--
-- Table structure for table `pma__pdf_pages`
--

CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__recent`
--

CREATE TABLE `pma__recent` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

-- --------------------------------------------------------

--
-- Table structure for table `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Table structure for table `pma__savedsearches`
--

CREATE TABLE `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_coords`
--

CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT '0',
  `x` float UNSIGNED NOT NULL DEFAULT '0',
  `y` float UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `display_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

--
-- Dumping data for table `pma__table_info`
--

INSERT INTO `pma__table_info` (`db_name`, `table_name`, `display_field`) VALUES
('JOINS', 'joins', 'name');

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_uiprefs`
--

CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `prefs` text COLLATE utf8_bin NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

--
-- Dumping data for table `pma__table_uiprefs`
--

INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'lab1', 'php', '{\"sorted_col\":\"`php`.`sex` ASC\"}', '2018-08-07 05:21:48'),
('root', 'notes', 'uploads', '{\"sorted_col\":\"`uploads`.`file_uploaded_to` ASC\"}', '2018-09-29 03:52:16'),
('root', 'portal', 'projdetail', '{\"sorted_col\":\"`projdetail`.`Updatedon` DESC\"}', '2018-10-02 20:05:40');

-- --------------------------------------------------------

--
-- Table structure for table `pma__tracking`
--

CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text COLLATE utf8_bin NOT NULL,
  `schema_sql` text COLLATE utf8_bin,
  `data_sql` longtext COLLATE utf8_bin,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') COLLATE utf8_bin DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__userconfig`
--

CREATE TABLE `pma__userconfig` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `config_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Dumping data for table `pma__userconfig`
--

INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2019-01-03 23:19:37', '{\"Console\\/Mode\":\"show\",\"Console\\/Height\":-49}');

-- --------------------------------------------------------

--
-- Table structure for table `pma__usergroups`
--

CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL,
  `tab` varchar(64) COLLATE utf8_bin NOT NULL,
  `allowed` enum('Y','N') COLLATE utf8_bin NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Table structure for table `pma__users`
--

CREATE TABLE `pma__users` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pma__central_columns`
--
ALTER TABLE `pma__central_columns`
  ADD PRIMARY KEY (`db_name`,`col_name`);

--
-- Indexes for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Indexes for table `pma__designer_settings`
--
ALTER TABLE `pma__designer_settings`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`);

--
-- Indexes for table `pma__favorite`
--
ALTER TABLE `pma__favorite`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Indexes for table `pma__navigationhiding`
--
ALTER TABLE `pma__navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- Indexes for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Indexes for table `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Indexes for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- Indexes for table `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Indexes for table `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indexes for table `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Indexes for table `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Indexes for table `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__usergroups`
--
ALTER TABLE `pma__usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- Indexes for table `pma__users`
--
ALTER TABLE `pma__users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Database: `pm`
--
CREATE DATABASE IF NOT EXISTS `pm` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `pm`;

-- --------------------------------------------------------

--
-- Table structure for table `pm`
--

CREATE TABLE `pm` (
  `id` bigint(20) NOT NULL,
  `id2` int(11) NOT NULL,
  `title` varchar(256) NOT NULL,
  `user1` bigint(20) NOT NULL,
  `user2` bigint(20) NOT NULL,
  `message` text NOT NULL,
  `timestamp` int(10) NOT NULL,
  `user1read` varchar(3) NOT NULL,
  `user2read` varchar(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `avatar` text NOT NULL,
  `signup_date` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- Database: `portal`
--
CREATE DATABASE IF NOT EXISTS `portal` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `portal`;

-- --------------------------------------------------------

--
-- Table structure for table `daily_log`
--

CREATE TABLE `daily_log` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `file_title` varchar(40) NOT NULL,
  `file_description` varchar(50) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_date` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(255) NOT NULL DEFAULT 'not approved yet'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `Email`, `Password`) VALUES
(1, 'yashi@gmail.com', 'yashi123'),
(2, 'tanmay@gmail.com', 'tanmay');

-- --------------------------------------------------------

--
-- Table structure for table `projdetail`
--

CREATE TABLE `projdetail` (
  `id` int(11) NOT NULL,
  `Name` varchar(25) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Department` varchar(50) NOT NULL,
  `Contact` varchar(10) NOT NULL,
  `ProjectName` varchar(40) NOT NULL,
  `URL` varchar(30) NOT NULL,
  `Description` varchar(50) NOT NULL,
  `Updatedon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `projdetail`
--

INSERT INTO `projdetail` (`id`, `Name`, `Email`, `Department`, `Contact`, `ProjectName`, `URL`, `Description`, `Updatedon`) VALUES
(1, 'yashi', ' yashi@gmail.com', 'it', '8967459834', 'gallery', 'http:/dk.io', 'joierj sekhto sonog', '2018-09-24 04:59:52'),
(2, 'aayu', ' aayu@gmail.com', 'cse', '9078563487', 'gdlixhgilkgn', 'http://op.io', 'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh', '2018-09-24 05:00:31');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Confirm` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Contact` varchar(50) NOT NULL,
  `Nationality` varchar(50) NOT NULL,
  `Roll` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `Name`, `Password`, `Confirm`, `Email`, `Contact`, `Nationality`, `Roll`) VALUES
(1, 'yashi', '  yashi123', ' yashi123', 'yashi@gmail.com', ' 7856349023', 'indian', 'teacher'),
(2, 'tanmay', '  tanmay', ' tanmay', 'tanmay@gmail.com', ' 8967452309', 'indian', 'student');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `daily_log`
--
ALTER TABLE `daily_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projdetail`
--
ALTER TABLE `projdetail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `daily_log`
--
ALTER TABLE `daily_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `projdetail`
--
ALTER TABLE `projdetail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Database: `sign`
--
CREATE DATABASE IF NOT EXISTS `sign` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `sign`;

-- --------------------------------------------------------

--
-- Table structure for table `sign`
--

CREATE TABLE `sign` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sign`
--

INSERT INTO `sign` (`id`, `username`, `password`) VALUES
(0, 'textuser', 'textuserpass'),
(0, 'textuser', 'textuserpass'),
(0, 'text', 'textuser');
--
-- Database: `signin`
--
CREATE DATABASE IF NOT EXISTS `signin` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `signin`;

-- --------------------------------------------------------

--
-- Table structure for table `nano`
--

CREATE TABLE `nano` (
  `id` int(11) NOT NULL,
  `TYPE` text,
  `minutes` int(11) DEFAULT NULL,
  `calories` int(11) DEFAULT NULL,
  `heart_beat` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nano`
--

INSERT INTO `nano` (`id`, `TYPE`, `minutes`, `calories`, `heart_beat`) VALUES
(1, 'biking', 2, 20, 45),
(2, 'racing', 3, 30, 145),
(3, 'horsing', 4, 70, 245),
(4, 'tree', 5, 40, 445),
(5, 'jumping', 6, 200, 345),
(6, 'cooking', 17, 300, 545);

-- --------------------------------------------------------

--
-- Table structure for table `signin`
--

CREATE TABLE `signin` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(0, 'textuser', 'testuserpass'),
(0, 'textuser', 'testuserpass');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `nano`
--
ALTER TABLE `nano`
  ADD PRIMARY KEY (`id`);
--
-- Database: `sql`
--
CREATE DATABASE IF NOT EXISTS `sql` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `sql`;

-- --------------------------------------------------------

--
-- Table structure for table `fire`
--

CREATE TABLE `fire` (
  `id` int(11) NOT NULL,
  `TYPE` text,
  `minutes` int(11) DEFAULT NULL,
  `calories` int(11) DEFAULT NULL,
  `heart_beat` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `first`
--

CREATE TABLE `first` (
  `id` int(11) NOT NULL,
  `TYPE` text,
  `minutes` int(11) DEFAULT NULL,
  `calories` int(11) DEFAULT NULL,
  `heart_beat` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fire`
--
ALTER TABLE `fire`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `first`
--
ALTER TABLE `first`
  ADD PRIMARY KEY (`id`);
--
-- Database: `test`
--
CREATE DATABASE IF NOT EXISTS `test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `test`;
--
-- Database: `testdb`
--
CREATE DATABASE IF NOT EXISTS `testdb` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `testdb`;

-- --------------------------------------------------------

--
-- Table structure for table `exer`
--

CREATE TABLE `exer` (
  `id` int(11) NOT NULL,
  `TYPE` text,
  `minutes` int(11) DEFAULT NULL,
  `calories` int(11) DEFAULT NULL,
  `heart_rate` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exer`
--

INSERT INTO `exer` (`id`, `TYPE`, `minutes`, `calories`, `heart_rate`) VALUES
(1, 'biking', 30, 100, 110),
(2, 'biking', 20, 300, 310),
(3, 'racing', 50, 500, 210);

-- --------------------------------------------------------

--
-- Table structure for table `exercise_log`
--

CREATE TABLE `exercise_log` (
  `id` int(11) NOT NULL,
  `TYPE` text,
  `minutes` int(11) DEFAULT NULL,
  `calories` int(11) DEFAULT NULL,
  `heart_rate` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exercise_log`
--

INSERT INTO `exercise_log` (`id`, `TYPE`, `minutes`, `calories`, `heart_rate`) VALUES
(1, 'biking', 30, 100, 110);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `exer`
--
ALTER TABLE `exer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exercise_log`
--
ALTER TABLE `exercise_log`
  ADD PRIMARY KEY (`id`);
--
-- Database: `tms`
--
CREATE DATABASE IF NOT EXISTS `tms` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `tms`;
--
-- Database: `trdb1`
--
CREATE DATABASE IF NOT EXISTS `trdb1` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `trdb1`;

-- --------------------------------------------------------

--
-- Table structure for table `login1`
--

CREATE TABLE `login1` (
  `Full Name` varchar(100) NOT NULL,
  `Father's Name` varchar(100) NOT NULL,
  `Mobile No.` int(11) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `Password` int(11) NOT NULL,
  `Retype` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login2`
--

CREATE TABLE `login2` (
  `Name` varchar(100) NOT NULL,
  `Fathers_Name` varchar(100) NOT NULL,
  `Mobile_No` int(11) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `Password` int(11) NOT NULL,
  `Retype` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login3`
--

CREATE TABLE `login3` (
  `id` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Fathers_Name` varchar(100) NOT NULL,
  `Mobile_No` varchar(100) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Retype` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login3`
--

INSERT INTO `login3` (`id`, `Name`, `Fathers_Name`, `Mobile_No`, `Username`, `Password`, `Retype`) VALUES
(1, 'jatin', '2347932749', 'yashu', '', '123', '123'),
(2, 'JAtin', '325985798', 'yahsu', '', '12345', '12345'),
(3, 'Rahul', '12378352', 'Taj', '', '1234', '1234'),
(4, 'Rahul', '23740247083', 'Uday', '', '7890', '7890');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login3`
--
ALTER TABLE `login3`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login3`
--
ALTER TABLE `login3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Database: `trdb2`
--
CREATE DATABASE IF NOT EXISTS `trdb2` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `trdb2`;
--
-- Database: `tr_student`
--
CREATE DATABASE IF NOT EXISTS `tr_student` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `tr_student`;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `usertype` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `usertype`) VALUES
('yaki', 'ayj8', 'asma'),
('wang', 'chang1', 'admin');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
