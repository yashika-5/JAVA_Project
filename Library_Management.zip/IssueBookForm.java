import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.JButton;

public class IssueBookForm extends JFrame implements ActionListener  {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	public IssueBookForm() {
		getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(262, 104, 153, 30);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(262, 157, 154, 30);
		getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(262, 218, 153, 30);
		getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(262, 278, 151, 30);
		getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblIssuebook = new JLabel("IssueBook");
		lblIssuebook.setBounds(222, 13, 56, 16);
		getContentPane().add(lblIssuebook);
		
		JLabel lblBookid = new JLabel("Book_id");
		lblBookid.setBounds(65, 111, 56, 16);
		getContentPane().add(lblBookid);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(65, 164, 56, 16);
		getContentPane().add(lblName);
		
		JLabel lblRollno = new JLabel("Roll_no");
		lblRollno.setBounds(65, 225, 56, 16);
		getContentPane().add(lblRollno);
		
		JLabel lblContact = new JLabel("Contact");
		lblContact.setBounds(65, 285, 56, 16);
		getContentPane().add(lblContact);
		
		JButton btnIssue = new JButton("Issue");
		btnIssue.setBounds(160, 358, 97, 36);
		getContentPane().add(btnIssue);
		
		JButton btnReset = new JButton("Reset");
		btnReset.setBounds(342, 358, 97, 36);
		getContentPane().add(btnReset);
	
	btnIssue.addActionListener(new ActionListener() 
	{
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		int x=0;
		String t1 = textField.getText();
		String t2 = textField_1.getText();
		String t3 = textField_2.getText();
		String t4 = textField_3.getText();
		
			try
			{
				Class.forName("com.mysql.jdbc.Driver");
            	Connection con = DriverManager.getConnection("jdbc:mysql://localhost/lbmgmt","root","");
        		System.out.println("connection is:"+con);
        		PreparedStatement ps = con.prepareStatement("insert into issued_book(Book_id,Name,Roll_no,Contact) values(?,?,?,?)");
        		 ps.setString(1, t1);
        		 ps.setString(2, t2);
        	     ps.setString(3, t3);
        		 ps.setString(4, t4);
        		
        		 int rs = ps.executeUpdate();
        		 x++;
        		 if (x > 0) 
                 {
                     JOptionPane.showMessageDialog((Component) btnIssue, "Data Saved Successfully");
                 }
			}
			 catch (Exception ex) 
			{
                System.out.println(ex);
            }		
		}
	}
	);
	btnReset.addActionListener(new ActionListener() 
	{
		public void actionPerformed(ActionEvent e) {
			textField.setText(" ");	
			textField_1.setText(" ");
			textField_2.setText(" ");
			textField_3.setText(" ");	
		}
		
	}
);
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}