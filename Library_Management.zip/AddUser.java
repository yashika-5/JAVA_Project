import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JPasswordField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.JButton;

public class AddUser extends JFrame implements ActionListener
{
	private JLabel  lblStudentRegistration;
	private JLabel lblName;
	private JLabel lblRollno;
	private JLabel lblGender;
	private JLabel lblMobile;
	private JLabel lblEmail;
	private JLabel lblBranch;
	private JLabel lblSemester;
	private JLabel lblPassword;
	private JComboBox  comboBox;
	private JButton  btnSave;
	private JButton  btnReset;
	private JButton  btnLogIn;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JPasswordField passwordField;
	public AddUser() {
		getContentPane().setLayout(null);
		
		 lblStudentRegistration = new JLabel("STUDENT REGISTRATION");
		lblStudentRegistration.setBounds(218, 13, 56, 16);
		getContentPane().add(lblStudentRegistration);
		
		 lblName = new JLabel("Name");
		lblName.setBounds(54, 56, 56, 16);
		getContentPane().add(lblName);
		
		lblRollno = new JLabel("Roll_no.");
		lblRollno.setBounds(54, 106, 56, 16);
		getContentPane().add(lblRollno);
		
		 lblGender = new JLabel("Gender");
		lblGender.setBounds(54, 156, 56, 16);
		getContentPane().add(lblGender);
		
		 lblMobile = new JLabel("Mobile");
		lblMobile.setBounds(54, 212, 56, 16);
		getContentPane().add(lblMobile);
		
		 lblEmail = new JLabel("Email");
		lblEmail.setBounds(54, 262, 56, 16);
		getContentPane().add(lblEmail);
		
		 lblBranch = new JLabel("Branch");
		lblBranch.setBounds(54, 305, 56, 16);
		getContentPane().add(lblBranch);
		
		 lblSemester = new JLabel("Semester");
		lblSemester.setBounds(54, 362, 56, 16);
		getContentPane().add(lblSemester);
		
		 lblPassword = new JLabel("Password");
		lblPassword.setBounds(54, 410, 56, 16);
		getContentPane().add(lblPassword);
		
		textField = new JTextField();
		textField.setBounds(181, 50, 321, 29);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(181, 100, 321, 29);
		getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		String s[] = {"Mail","Female"};
		 comboBox = new JComboBox(s);
		comboBox.setBounds(181, 153, 81, 29);
		getContentPane().add(comboBox);
		
		textField_2 = new JTextField();
		textField_2.setBounds(179, 199, 323, 29);
		getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(181, 249, 321, 29);
		getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(181, 299, 321, 29);
		getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(181, 356, 321, 29);
		getContentPane().add(textField_5);
		textField_5.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(181, 407, 321, 29);
		getContentPane().add(passwordField);
		
		 btnSave = new JButton("SAVE");
		btnSave.setBounds(37, 498, 97, 37);
		getContentPane().add(btnSave);
		
		 btnReset = new JButton("RESET");
		btnReset.setBounds(218, 498, 97, 37);
		getContentPane().add(btnReset);
		
		btnLogIn = new JButton("LOG IN");
		btnLogIn.setBounds(391, 498, 97, 37);
		getContentPane().add(btnLogIn);
		
		btnSave.addActionListener(this);
		btnReset.addActionListener(this);
		btnLogIn.addActionListener(this);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		int x=0;
		String t1 = textField.getText();
		String t2 = textField_1.getText();
		String t3 = textField_2.getText();
		String t4 = textField_3.getText();
		String t5 = textField_4.getText();
		String t6 = textField_5.getText();
		
		char t7[] = passwordField.getPassword();
		String t8 = new String(t7);
		String t9 = (String) comboBox.getSelectedItem();
		
		
		if(e.getSource()==btnSave)
		{
			try
			{
				Class.forName("com.mysql.jdbc.Driver");
            	Connection con = DriverManager.getConnection("jdbc:mysql://localhost/lbmgmt","root","");
        		System.out.println("connection is:"+con);
        		PreparedStatement ps = con.prepareStatement("insert into add_user(Name,Roll_no,Gender,Mobile,Email,Branch,Semester,Password) values(?,?,?,?,?,?,?,?)");
        		 ps.setString(1, t1);
        		 ps.setString(2, t2);
        	     ps.setString(3, t9);
        		 ps.setString(4, t3);
        		 ps.setString(5, t4);
        		 ps.setString(6, t5);
        		 ps.setString(7, t6);
        		 ps.setString(8, t8); 
        		 int rs = ps.executeUpdate();
        		 x++;
        		 if (x > 0) 
                 {
                     JOptionPane.showMessageDialog(btnSave, "Data Saved Successfully");
                 }
			}
			 catch (Exception ex) 
			{
                System.out.println(ex);
            }		
		}
		else if(e.getSource()==btnReset)
		{
			textField.setText(" ");	
			textField_1.setText(" ");
			textField_2.setText(" ");
			textField_3.setText(" ");
			textField_4.setText(" ");
			textField_5.setText(" ");
			passwordField.setText(" ");
			 comboBox.setSelectedIndex(0);
		}
		else
		{
			Login li = new Login();
			li.setVisible(true);
		}
	}
}
