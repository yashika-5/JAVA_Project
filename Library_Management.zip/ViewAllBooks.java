import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;

public class ViewAllBooks extends JFrame{
	
	private JLabel lblAllBooks;
	int x = 0;
	public ViewAllBooks() {
		getContentPane().setLayout(null);
		
		lblAllBooks = new JLabel("ALL BOOKS");
		lblAllBooks.setBounds(209, 46, 56, 16);
		getContentPane().add(lblAllBooks);
		
    
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
        	Connection con = DriverManager.getConnection("jdbc:mysql://localhost/lbmgmt","root","");
    		System.out.println("connection is:"+con);
    		PreparedStatement ps = con.prepareStatement("Select * from add_book");
    		 
    		 ResultSet rs = ps.executeQuery();
    		 x++;
    		 if (x > 0) 
             {
                 JOptionPane.showMessageDialog(getParent(), "all books are shown Successfully");
             }
		}
		 catch (Exception ex) 
        {
            System.out.println(ex);
        }			

	}
}
