import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

public class ChangePassword extends JFrame{
	private JTextField textField;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;
	public ChangePassword() {
		getContentPane().setLayout(null);
		
		JLabel lblRollno = new JLabel("RollNo");
		lblRollno.setBounds(48, 37, 56, 16);
		getContentPane().add(lblRollno);
		
		JLabel lblOldPassword = new JLabel("Old Password");
		lblOldPassword.setBounds(48, 103, 56, 16);
		getContentPane().add(lblOldPassword);
		
		JLabel lblNewPassword = new JLabel("New Password");
		lblNewPassword.setBounds(48, 168, 56, 16);
		getContentPane().add(lblNewPassword);
		
		textField = new JTextField();
		textField.setBounds(208, 34, 232, 29);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(209, 158, 225, 29);
		getContentPane().add(passwordField);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(208, 93, 232, 29);
		getContentPane().add(passwordField_1);
		
		JButton btnOk = new JButton("OK");
		btnOk.setBounds(184, 258, 97, 40);
		getContentPane().add(btnOk);
	
	
	
	
	btnOk.addActionListener(new ActionListener() 
	{
		public void actionPerformed(ActionEvent arg0) 
		{
			 String rol=textField.getText();
			  
			  char t7[] = passwordField.getPassword();
				String t8 = new String(t7);
			  if(rol.length()==0 || t8.length()==0)
			  {
				  JOptionPane.showMessageDialog(ChangePassword.this, "Pls fill/select all the fields", "Error", JOptionPane.ERROR_MESSAGE);				  
			  }
			  else
			  {
				  
			
String query="update add_user set Roll_no=?,Password=? where Roll_no=?";
			  int flag=0;
			  Connection con=DBInfo.con;
			  try
			  {
				 PreparedStatement ps=con.prepareStatement(query);
				 ps.setString(1,rol);
				 ps.setString(2, t8);
				 ps.setString(3, rol);
				 
				 flag=ps.executeUpdate();
				 
			  }
			  catch(Exception e)
			  {
				  e.printStackTrace();
			  }
			  if(flag==1)
			  {
				  JOptionPane.showMessageDialog(ChangePassword.this, "Password updated!!", "Success", JOptionPane.INFORMATION_MESSAGE);
			      textField.setText(null);
			      passwordField.setText(null);
			     /* .setText(null);*/
			     
			      
			      
			  }
			  else
			  {
				  JOptionPane.showMessageDialog(ChangePassword.this, "Password not Updated", "Error", JOptionPane.ERROR_MESSAGE);
			  }
			  }
		}			  
	});
}
}
