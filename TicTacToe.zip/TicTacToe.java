import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TicTacToe extends JFrame{
	public JButton button_1;
	public JButton button_2;
	public JButton button_3;
	public JButton button_4;
	public JButton button_5;
	public JButton button_6;
	public JButton button_7;
	public JButton button_8;
	public JButton button_9;
	
	Main main = new Main();

	public TicTacToe() {
		getContentPane().setLayout(null);
	
		setTitle("Tic Tac Toe");
		
		
		 button_1 = new JButton("");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(button_1.getText().equals("")) {
					if(Main.playerTurn == true) {
						button_1.setText("X");
						Main.checkforwin();
						Main.playerTurn = false;
					}
					else {
						button_1.setText("O");
						Main.checkforwin();
						Main.playerTurn = true;
					}
				}
			}
		});
		button_1.setBounds(45, 110, 140, 118);
		getContentPane().add(button_1);
		
		 button_2 = new JButton("");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(button_2.getText().equals("")) {
					if(Main.playerTurn == true) {
						button_2.setText("X");
						Main.checkforwin();
						Main.playerTurn = false;
					}
					else {
						button_2.setText("O");
						Main.checkforwin();
						Main.playerTurn = true;
					}
				}
			}
		});
		button_2.setBounds(215, 110, 147, 118);
		getContentPane().add(button_2);
		
		 button_3 = new JButton("");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(button_3.getText().equals("")) {
					if(Main.playerTurn == true) {
						button_3.setText("X");
						Main.checkforwin();
						Main.playerTurn = false;
					}
					else {
						button_3.setText("O");
						Main.checkforwin();
						Main.playerTurn = true;
					}
				}
			}
		});
		button_3.setBounds(390, 110, 147, 118);
		getContentPane().add(button_3);
		
		 button_4 = new JButton("");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(button_4.getText().equals("")) {
					if(Main.playerTurn == true) {
						button_4.setText("X");
						Main.checkforwin();
						Main.playerTurn = false;
					}
					else {
						button_4.setText("O");
						Main.checkforwin();
						Main.playerTurn = true;
					}
				}
			}
		});
		button_4.setBounds(45, 262, 140, 118);
		getContentPane().add(button_4);
		
		 button_5 = new JButton("");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(button_5.getText().equals("")) {
					if(Main.playerTurn == true) {
						button_5.setText("X");
						Main.checkforwin();
						Main.playerTurn = false;
					}
					else {
						button_5.setText("O");
						Main.checkforwin();
						Main.playerTurn = true;
					}
				}
			}
		});
		button_5.setBounds(215, 262, 147, 118);
		getContentPane().add(button_5);
		
		 button_6 = new JButton("");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(button_6.getText().equals("")) {
					if(Main.playerTurn == true) {
						button_6.setText("X");
						Main.checkforwin();
						Main.playerTurn = false;
					}
					else {
						button_6.setText("O");
						Main.checkforwin();
						Main.playerTurn = true;
					}
				}
			}
		});
		button_6.setBounds(390, 262, 147, 118);
		getContentPane().add(button_6);
		
		 button_7 = new JButton("");
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(button_7.getText().equals("")) {
					if(Main.playerTurn == true) {
						button_7.setText("X");
						Main.checkforwin();
						Main.playerTurn = false;
					}
					else {
						button_7.setText("O");
						Main.checkforwin();
						Main.playerTurn = true;
					}
				}
			}
		});
		button_7.setBounds(45, 411, 140, 118);
		getContentPane().add(button_7);
		
		 button_8 = new JButton("");
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(button_8.getText().equals("")) {
					if(Main.playerTurn == true) {
						button_8.setText("X");
						Main.checkforwin();
						Main.playerTurn = false;
					}
					else {
						button_8.setText("O");
						Main.checkforwin();
						Main.playerTurn = true;
					}
				}
			}
		});
		button_8.setBounds(215, 411, 147, 118);
		getContentPane().add(button_8);
		
		 button_9 = new JButton("");
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(button_9.getText().equals("")) {
					if(Main.playerTurn == true) {
						button_9.setText("X");
						Main.checkforwin();
						Main.playerTurn = false;
					}
					else {
						button_9.setText("O");
						Main.checkforwin();
						Main.playerTurn = true;
					}
				}
			}
		});
		button_9.setBounds(390, 411, 147, 118);
		getContentPane().add(button_9);
	



		
	
}
}
