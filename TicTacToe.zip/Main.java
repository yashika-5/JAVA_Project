import java.util.Scanner;

public class Main{
	
	public static boolean playerTurn = true;
	public static boolean playerWon = false;
	public static boolean computerWon = false;
	public static boolean playing = true;
	public static boolean playAgain = true;
	static Scanner scan = new Scanner(System.in);
	
	static TicTacToe board = new TicTacToe();
	
	public static void main(String[] args) {
	    
		   if(board.isVisible() == false) {
		 	  board.setVisible(true);
		  }
	    
	}
	
	public static void checkforwin() {
		if(board.button_1.getText().equals("X")) {
			if(board.button_4.getText().equals("X")) {
				if(board.button_7.getText().equals("X")) {
					playerWon = true;
					computerWon = false;
					System.out.println("Player Won!!");
				}
			}
		}
		
		if(board.button_1.getText().equals("X")) {
			if(board.button_5.getText().equals("X")) {
				if(board.button_9.getText().equals("X")) {
					playerWon = true;
					computerWon = false;
					System.out.println("Player Won!!");
				}
			}
		}
		
		if(board.button_1.getText().equals("X")) {
			if(board.button_2.getText().equals("X")) {
				if(board.button_3.getText().equals("X")) {
					playerWon = true;
					computerWon = false;
					System.out.println("Player Won!!");
				}
			}
		}
		
		if(board.button_3.getText().equals("X")) {
			if(board.button_6.getText().equals("X")) {
				if(board.button_9.getText().equals("X")) {
					playerWon = true;
					computerWon = false;
					System.out.println("Player Won!!");
				}
			}
		}
		
		if(board.button_7.getText().equals("X")) {
			if(board.button_8.getText().equals("X")) {
				if(board.button_9.getText().equals("X")) {
					playerWon = true;
					computerWon = false;
					System.out.println("Player Won!!");
				}
			}
		}
		
		if(board.button_4.getText().equals("X")) {
			if(board.button_5.getText().equals("X")) {
				if(board.button_6.getText().equals("X")) {
					playerWon = true;
					computerWon = false;
					System.out.println("Player Won!!");
				}
			}
		}
		
		if(board.button_3.getText().equals("X")) {
			if(board.button_5.getText().equals("X")) {
				if(board.button_7.getText().equals("X")) {
					playerWon = true;
					computerWon = false;
					System.out.println("Player Won!!");
				}
			}
		}
		
		
		
		if(board.button_2.getText().equals("X")) {
			if(board.button_5.getText().equals("X")) {
				if(board.button_8.getText().equals("X")) {
					playerWon = true;
					computerWon = false;
					System.out.println("Player Won!!");
				}
			}
		}
		
		
		if(board.button_1.getText().equals("O")) {
			if(board.button_4.getText().equals("O")) {
				if(board.button_7.getText().equals("O")) {
					playerWon = false;
					computerWon = true;
					System.out.println("Player2 Won!!");
				}
			}
		}
		
		if(board.button_1.getText().equals("O")) {
			if(board.button_5.getText().equals("O")) {
				if(board.button_9.getText().equals("O")) {
					playerWon = false;
					computerWon = true;
					System.out.println("Player2 Won!!");
				}
			}
		}
		
		if(board.button_1.getText().equals("O")) {
			if(board.button_2.getText().equals("O")) {
				if(board.button_3.getText().equals("O")) {
					playerWon = false;
					computerWon = true;
					System.out.println("Player2 Won!!");
				}
			}
		}
		
		if(board.button_3.getText().equals("O")) {
			if(board.button_6.getText().equals("O")) {
				if(board.button_9.getText().equals("O")) {
					playerWon = false;
					computerWon = true;
					System.out.println("Player2 Won!!");
				}
			}
		}
		
		if(board.button_7.getText().equals("O")) {
			if(board.button_8.getText().equals("O")) {
				if(board.button_9.getText().equals("O")) {
					playerWon = false;
					computerWon = true;
					System.out.println("Player2 Won!!");
				}
			}
		}
		
		if(board.button_4.getText().equals("O")) {
			if(board.button_5.getText().equals("O")) {
				if(board.button_6.getText().equals("O")) {
					playerWon = false;
					computerWon = true;
					System.out.println("Player2 Won!!");
				}
			}
		}
		
		if(board.button_3.getText().equals("O")) {
			if(board.button_5.getText().equals("O")) {
				if(board.button_7.getText().equals("O")) {
					playerWon = false;
					computerWon = true;
					System.out.println("Player2 Won!!");
				}
			}
		}
		
		
		if(board.button_2.getText().equals("O")) {
			if(board.button_5.getText().equals("O")) {
				if(board.button_8.getText().equals("O")) {
					playerWon = false;
					computerWon = true;
					System.out.println("Player2 Won!!");
				}
			}
		}
		if(playerWon == true || computerWon == true) {
		/*	board.setVisible(false);*/
			System.out.println("Would you like to play again? True or False");
			playAgain = scan.nextBoolean();
			if(playAgain == true) {
				board.setVisible(false);
				System.out.println("Player 1 won :" +playerWon);
				System.out.println("Player 2 won :" +computerWon);
				board.button_1.setText("");
				board.button_2.setText("");
				board.button_3.setText("");
				board.button_4.setText("");
				board.button_5.setText("");
				board.button_6.setText("");
				board.button_7.setText("");
				board.button_8.setText("");
				board.button_9.setText("");
				playerTurn = true;
				playerWon = false;
				computerWon = false;
				board.setVisible(true);
			}
			else {
				System.out.println("Thanks for playing ...");
			}
		}
		
		
	}
}